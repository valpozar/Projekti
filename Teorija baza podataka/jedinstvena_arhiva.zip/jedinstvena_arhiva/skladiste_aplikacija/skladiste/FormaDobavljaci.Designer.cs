﻿namespace skladiste
{
    partial class FormaDobavljaci
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvPrikazDobavljaca = new System.Windows.Forms.DataGridView();
            this.inputPretraga = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnIzlaz = new System.Windows.Forms.Button();
            this.btnDodajDobavljaca = new System.Windows.Forms.Button();
            this.btnAzurirajPodatkeDobavljaca = new System.Windows.Forms.Button();
            this.btnIzbrisiDobavljaca = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPrikazDobavljaca)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvPrikazDobavljaca
            // 
            this.dgvPrikazDobavljaca.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPrikazDobavljaca.BackgroundColor = System.Drawing.SystemColors.ScrollBar;
            this.dgvPrikazDobavljaca.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPrikazDobavljaca.Location = new System.Drawing.Point(83, 64);
            this.dgvPrikazDobavljaca.Name = "dgvPrikazDobavljaca";
            this.dgvPrikazDobavljaca.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPrikazDobavljaca.Size = new System.Drawing.Size(496, 208);
            this.dgvPrikazDobavljaca.TabIndex = 25;
            // 
            // inputPretraga
            // 
            this.inputPretraga.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.inputPretraga.Location = new System.Drawing.Point(479, 29);
            this.inputPretraga.Name = "inputPretraga";
            this.inputPretraga.Size = new System.Drawing.Size(100, 20);
            this.inputPretraga.TabIndex = 32;
            this.inputPretraga.TextChanged += new System.EventHandler(this.inputPretraga_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(355, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 13);
            this.label1.TabIndex = 31;
            this.label1.Text = "Pretraga po nazivu:";
            // 
            // btnIzlaz
            // 
            this.btnIzlaz.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnIzlaz.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIzlaz.Location = new System.Drawing.Point(12, 12);
            this.btnIzlaz.Name = "btnIzlaz";
            this.btnIzlaz.Size = new System.Drawing.Size(39, 25);
            this.btnIzlaz.TabIndex = 33;
            this.btnIzlaz.Text = "<--";
            this.btnIzlaz.UseVisualStyleBackColor = false;
            this.btnIzlaz.Click += new System.EventHandler(this.btnIzlaz_Click);
            // 
            // btnDodajDobavljaca
            // 
            this.btnDodajDobavljaca.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnDodajDobavljaca.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnDodajDobavljaca.Location = new System.Drawing.Point(120, 298);
            this.btnDodajDobavljaca.Name = "btnDodajDobavljaca";
            this.btnDodajDobavljaca.Size = new System.Drawing.Size(109, 53);
            this.btnDodajDobavljaca.TabIndex = 34;
            this.btnDodajDobavljaca.Text = "DODAJ DOBAVLJAČA U BAZU";
            this.btnDodajDobavljaca.UseVisualStyleBackColor = false;
            this.btnDodajDobavljaca.Click += new System.EventHandler(this.btnDodajDobavljaca_Click);
            // 
            // btnAzurirajPodatkeDobavljaca
            // 
            this.btnAzurirajPodatkeDobavljaca.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnAzurirajPodatkeDobavljaca.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnAzurirajPodatkeDobavljaca.Location = new System.Drawing.Point(275, 298);
            this.btnAzurirajPodatkeDobavljaca.Name = "btnAzurirajPodatkeDobavljaca";
            this.btnAzurirajPodatkeDobavljaca.Size = new System.Drawing.Size(110, 53);
            this.btnAzurirajPodatkeDobavljaca.TabIndex = 35;
            this.btnAzurirajPodatkeDobavljaca.Text = "AŽURIRAJ PODATKE DOBAVLJAČA";
            this.btnAzurirajPodatkeDobavljaca.UseVisualStyleBackColor = false;
            this.btnAzurirajPodatkeDobavljaca.Click += new System.EventHandler(this.btnAzurirajPodatkeDobavljaca_Click);
            // 
            // btnIzbrisiDobavljaca
            // 
            this.btnIzbrisiDobavljaca.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnIzbrisiDobavljaca.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnIzbrisiDobavljaca.Location = new System.Drawing.Point(429, 298);
            this.btnIzbrisiDobavljaca.Name = "btnIzbrisiDobavljaca";
            this.btnIzbrisiDobavljaca.Size = new System.Drawing.Size(110, 53);
            this.btnIzbrisiDobavljaca.TabIndex = 36;
            this.btnIzbrisiDobavljaca.Text = "IZBRIŠI DOBAVLJAČA IZ BAZE";
            this.btnIzbrisiDobavljaca.UseVisualStyleBackColor = false;
            this.btnIzbrisiDobavljaca.Click += new System.EventHandler(this.btnIzbrisiDobavljaca_Click);
            // 
            // FormaDobavljaci
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(663, 363);
            this.Controls.Add(this.btnIzbrisiDobavljaca);
            this.Controls.Add(this.btnAzurirajPodatkeDobavljaca);
            this.Controls.Add(this.btnDodajDobavljaca);
            this.Controls.Add(this.btnIzlaz);
            this.Controls.Add(this.inputPretraga);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgvPrikazDobavljaca);
            this.Name = "FormaDobavljaci";
            this.Text = "Prikaz dobavljača";
            this.Load += new System.EventHandler(this.FormaDobavljaci_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPrikazDobavljaca)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvPrikazDobavljaca;
        private System.Windows.Forms.TextBox inputPretraga;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnIzlaz;
        private System.Windows.Forms.Button btnDodajDobavljaca;
        private System.Windows.Forms.Button btnAzurirajPodatkeDobavljaca;
        private System.Windows.Forms.Button btnIzbrisiDobavljaca;
    }
}