﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace skladiste
{
    public partial class FormaIzradaPrimke : Form
    {
        int idKorisnika;

        public FormaIzradaPrimke(int id)
        {
            InitializeComponent();
            idKorisnika = id;
        }

        private void btnIzlaz_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormaIzbornik formaIzbornik = new FormaIzbornik();
            formaIzbornik.Closed += (s, args) => this.Close();
            formaIzbornik.ShowDialog();
        }

        private void OsvjeziNarudzbenice()
        {
            List<Narudzbenica> listaNarudzbenica = Narudzbenica.DohvatiNarudzbenice();
            dgvNarudzbenice.DataSource = listaNarudzbenica;
        }

        private void OsvjeziComboBox()
        {
            List<PrimkaIzrada> listaIdPrimki = PrimkaIzrada.DohvatiIdPrimke();
            cmbIdPrimke.DataSource = listaIdPrimki;
        }

        private void OsvjeziArtikle()
        {
            List<ArtiklUpravljanje> listaArtikala = ArtiklUpravljanje.DohvacanjeArtikala();
            dgvArtikli.DataSource = listaArtikala;
        }

        private void FormaIzradaPrimke_Load(object sender, EventArgs e)
        {
            OsvjeziNarudzbenice();
            OsvjeziComboBox();
            OsvjeziArtikle();
        }

        private void OsvjeziStavkeNarudzbenice()
        {
            Narudzbenica odabranaNarudzbenica = dgvNarudzbenice.CurrentRow.DataBoundItem as Narudzbenica;

            StavkaNarudzbenice sn = new StavkaNarudzbenice();

            dgvStavkaNarudzbenice.DataSource = sn.DohvatiStavkeNarudzbenice(odabranaNarudzbenica.IdNarudzbenice);
        }

        private void dgvNarudzbenice_SelectionChanged(object sender, EventArgs e)
        {
            OsvjeziStavkeNarudzbenice();
        }

        private void actionPretrazi_Click(object sender, EventArgs e)
        {
            int pretraga = int.Parse(inputIdNarudzbenice.Text);
            inputIdNarudzbenice.Clear();
            int id = 0;

            foreach (DataGridViewRow dgvr in dgvNarudzbenice.Rows)
            {
                id = Convert.ToInt32(dgvr.Cells[0].Value);

                if (pretraga == id)
                {
                    List<Narudzbenica> listaNarudzbenica = Narudzbenica.DohvatiPretrazeneNarudzbenice(pretraga);
                    dgvNarudzbenice.DataSource = listaNarudzbenica;
                }

            }
            if (pretraga != id)
            {
                MessageBox.Show("Uneseni Id ne postoji!");
            }
        }

        private void actionSveNarudzbenice_Click(object sender, EventArgs e)
        {
            OsvjeziNarudzbenice();
        }

        private void actionPretraziArtikle_Click(object sender, EventArgs e)
        {
            string pretraga = inputNazivArtikla.Text;
            inputNazivArtikla.Clear();
            string naziv = "";


            foreach (DataGridViewRow dgvr in dgvArtikli.Rows)
            {
                naziv = (dgvr.Cells[1].Value).ToString();

                if (pretraga == naziv)
                {
                    List<ArtiklUpravljanje> listaArtikala = ArtiklUpravljanje.DohvacanjePretrazenihArtikala(pretraga);
                    dgvArtikli.DataSource = listaArtikala;
                }

            }
            if (pretraga != naziv)
            {
                MessageBox.Show("Uneseni naziv ne postoji!");
            }
        }

        private void actionSviArtikli_Click(object sender, EventArgs e)
        {
            OsvjeziArtikle();
        }

        private void actionIzradiPrimku_Click(object sender, EventArgs e)
        {
            string poruka = "";
            int idNarudzbenice = -1, brojOtpremnice = -1;
            float ukupniIznos = -1;
            try
            {
                if (!string.IsNullOrWhiteSpace(inputIdNarudzbeniceUnos.Text))
                {
                    idNarudzbenice = int.Parse(inputIdNarudzbeniceUnos.Text);
                }

                if (!string.IsNullOrWhiteSpace(inputBrojOtpremnice.Text))
                {
                    brojOtpremnice = int.Parse(inputBrojOtpremnice.Text);
                }

                if (!string.IsNullOrWhiteSpace(inputUkupanIznos.Text))
                {
                    ukupniIznos = float.Parse(inputUkupanIznos.Text);
                }

                string napomena = inputNapomena.Text;
                DateTime datum = dtpDatum.Value;
                int idZaposlenika = idKorisnika;

                inputIdNarudzbeniceUnos.Clear();
                inputNapomena.Clear();
                inputBrojOtpremnice.Clear();
                inputUkupanIznos.Clear();

                Primka primka = new Primka();
               
                primka.DodavanjePrimke(datum, brojOtpremnice, napomena, ukupniIznos, idKorisnika, idNarudzbenice);
            }
            catch (Exception ex)
            {
                poruka = ex.Message;
            }
            finally
            {
                if (!poruka.Equals(""))
                    MessageBox.Show(poruka, "Upozorenje", MessageBoxButtons.OK);
            }
           

            OsvjeziComboBox();
        }

        private void actionDodajStavke_Click(object sender, EventArgs e)
        {
            int kolicina = int.Parse(inputKolicina.Text);
            int idPrimke = int.Parse(cmbIdPrimke.SelectedValue.ToString());
            int idArtikla = int.Parse(inputIdArtikla.Text);

            inputKolicina.Clear();
            inputIdArtikla.Clear();

            StavkaPrimke stavkaPrimke = new StavkaPrimke(kolicina, idPrimke, idArtikla);
            stavkaPrimke.DodajStavkuPrimke();
        }

        private void dgvArtikli_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvArtikli.CurrentRow != null)
            {
                DataGridViewRow selektiraniRedak = dgvArtikli.CurrentRow;
                DataGridViewCell selektiraniId = selektiraniRedak.Cells[0];
                int idArtikla = int.Parse(selektiraniId.Value.ToString());
                lblKolicina.Text = "Količina na skladištu (odabranog artikla): " + StavkaPrimke.DohvatiKolicinuSaSkladista(idArtikla);
            }
        }
    }
}
