﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace skladiste
{
    public partial class FormaPregledRacuna : Form
    {
        public FormaPregledRacuna()
        {
            InitializeComponent();
        }

        private void btnIzlaz_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormaIzbornik formaIzbornik = new FormaIzbornik();
            formaIzbornik.Closed += (s, args) => this.Close();
            formaIzbornik.ShowDialog();
        }

        private void OsvjeziRacune()
        {
            List<Racun> listaRacuna = Racun.DohvatiRacune();
            dgvRacuni.DataSource = listaRacuna;
        }

        private void PretraziRacune()
        {
            int pretraga = int.Parse(inputIdRacuna.Text);
            inputIdRacuna.Clear();
            int id = 0;

            foreach (DataGridViewRow dgvr in dgvRacuni.Rows)
            {
                id = Convert.ToInt32(dgvr.Cells[0].Value);

                if (pretraga == id)
                {
                    List<Racun> listaRacuna = Racun.DohvatiPretrazeneRacune(pretraga);
                    dgvRacuni.DataSource = listaRacuna;
                }
            }

            if (pretraga != id)
            {
                MessageBox.Show("Uneseni Id ne postoji!");
            }
        }

        private void FormaPregledRacuna_Load(object sender, EventArgs e)
        {
            OsvjeziRacune();
        }

        private void actionPretrazi_Click(object sender, EventArgs e)
        {
            PretraziRacune();
        }

        private void actionSviRacuni_Click(object sender, EventArgs e)
        {
            OsvjeziRacune();
        }

        private void actionObrisiRacun_Click(object sender, EventArgs e)
        {
            if (dgvRacuni.SelectedRows.Count > 0)
            {
                foreach (DataGridViewRow row in dgvRacuni.SelectedRows)
                {
                    Racun odabraniRacun = row.DataBoundItem as Racun;
                    odabraniRacun.BrisanjeRacuna();
                }

                MessageBox.Show("Uspješno ste obrisali račun iz baze podataka!", "Uspješno brisanje računa!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            else
            {
                MessageBox.Show("Niste odabrali račun za brisanje!", "Upozorenje!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            OsvjeziRacune();
        }

        private void OsvjeziStavkeRacuna()
        {
            Racun odabraniRacun = dgvRacuni.CurrentRow.DataBoundItem as Racun;

            StavkaRacuna sr = new StavkaRacuna();

            dgvStavkaRacuna.DataSource = sr.DohvatiStavkeRacuna(odabraniRacun.IdRacuna);

        }

        private void dgvRacuni_SelectionChanged(object sender, EventArgs e)
        {
            OsvjeziStavkeRacuna();
        }

        private void actionAzurirajRacun_Click(object sender, EventArgs e)
        {
            if (dgvRacuni.SelectedRows.Count > 0)
            {
                Racun odabraniRacun = dgvRacuni.SelectedRows[0].DataBoundItem as Racun;

                this.Hide();
                FormaAzuriranjeRacuna formaAzuriranjeRacuna = new FormaAzuriranjeRacuna(odabraniRacun);
                formaAzuriranjeRacuna.Closed += (s, args) => this.Close();
                formaAzuriranjeRacuna.ShowDialog();
                OsvjeziRacune();
            }
            else
            {
                MessageBox.Show("Niste odabrali račun za ažuriranje!", "Upozorenje!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
