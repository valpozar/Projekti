﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace skladiste
{
    public partial class FormaDostupniArtikli : Form
    {
        public FormaDostupniArtikli()
        {
            InitializeComponent();
        }

        private void btnIzlaz_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormaIzbornik formaIzbornik = new FormaIzbornik();
            formaIzbornik.FormClosed += (s, args) => this.Close();
            formaIzbornik.ShowDialog();
        }

        private void OsvjeziArtikle()
        {

            List<Artikl> listaArtikala = Artikl.DohvacanjePretrazenihArtikala(inputPretraga.Text);
            dgvPrikazArtikala.DataSource = listaArtikala;
        }

        private void inputPretraga_TextChanged(object sender, EventArgs e)
        {
            OsvjeziArtikle();
        }

        private void FormaDostupniArtikli_Load(object sender, EventArgs e)
        {
            OsvjeziArtikle();
        }
    }
}
