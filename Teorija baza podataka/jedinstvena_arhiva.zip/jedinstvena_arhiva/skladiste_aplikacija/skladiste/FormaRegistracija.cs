﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace skladiste
{
    public partial class FormaRegistracija : Form
    {
        public FormaRegistracija()
        {
            InitializeComponent();
            inputLozinka.PasswordChar = '*';
            inputPotvrdaLozinke.PasswordChar = '*';
        }

        private void btnIzlaz_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormaPocetak pocetakForma = new FormaPocetak();
            pocetakForma.FormClosed += (s, args) => this.Close();
            pocetakForma.ShowDialog();
        }

        private void btnRegistrirajSe_Click(object sender, EventArgs e)
        {
            string ime = inputIme.Text;
            string prezime = inputPrezime.Text;
            string email = inputEmail.Text;
            string lozinka = inputLozinka.Text;
            string potvrdaLozinke = inputPotvrdaLozinke.Text;
            string adresa = inputAdresa.Text;
            string kontakt = inputKontakt.Text;

            int postojiEmail = 0;

            if (String.IsNullOrWhiteSpace(ime) || String.IsNullOrWhiteSpace(prezime) || String.IsNullOrWhiteSpace(email) || String.IsNullOrWhiteSpace(lozinka) || String.IsNullOrWhiteSpace(potvrdaLozinke) || String.IsNullOrWhiteSpace(adresa) || String.IsNullOrWhiteSpace(kontakt))
            {
                MessageBox.Show("Morate unijeti sve podatke!", "Upozorenje!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (lozinka.Equals(potvrdaLozinke) == false)
            {
                MessageBox.Show("Lozinka i potvrda lozinke moraju biti jednake!", "Upozorenje!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                postojiEmail = Korisnik.ProvjeraEmaila(email);

                if (postojiEmail == 1)
                {
                    MessageBox.Show("Uneseni email već postoji!", "Upozorenje!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    Korisnik noviKupac = new Korisnik(ime, prezime, email, lozinka, adresa, kontakt);
                    noviKupac.UnosNovogKupcaUBazu();

                    MessageBox.Show("Uspješna registracija!", "Uspješna registracija", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    inputIme.Clear();
                    inputPrezime.Clear();
                    inputEmail.Clear();
                    inputLozinka.Clear();
                    inputPotvrdaLozinke.Clear();
                    inputAdresa.Clear();
                    inputKontakt.Clear();
                }
            }
        }
    }
}
