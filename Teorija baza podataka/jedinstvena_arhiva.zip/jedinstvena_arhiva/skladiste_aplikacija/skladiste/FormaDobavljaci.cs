﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace skladiste
{
    public partial class FormaDobavljaci : Form
    {
        public FormaDobavljaci()
        {
            InitializeComponent();
        }

        private void btnIzlaz_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormaIzbornik formaIzbornik = new FormaIzbornik();
            formaIzbornik.FormClosed += (s, args) => this.Close();
            formaIzbornik.ShowDialog();
        }

        private void OsvjeziDobavljaca()
        {
            List<Dobavljac> listaDobavljaca = Dobavljac.DohvacanjeDobavljaca(inputPretraga.Text);
            dgvPrikazDobavljaca.DataSource = listaDobavljaca;
        }

        private void FormaDobavljaci_Load(object sender, EventArgs e)
        {
            OsvjeziDobavljaca();
        }

        private void inputPretraga_TextChanged(object sender, EventArgs e)
        {
            OsvjeziDobavljaca();
        }

        private void btnDodajDobavljaca_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormaUnosDobavljaca formaUnosDobavljaca = new FormaUnosDobavljaca();
            formaUnosDobavljaca.Closed += (s, args) => this.Close();
            formaUnosDobavljaca.ShowDialog();
            OsvjeziDobavljaca();
        }

        private void btnAzurirajPodatkeDobavljaca_Click(object sender, EventArgs e)
        {
            if (dgvPrikazDobavljaca.SelectedRows.Count > 0)
            {
                Dobavljac odabraniDobavljac = dgvPrikazDobavljaca.SelectedRows[0].DataBoundItem as Dobavljac;

                this.Hide();
                FormaAzuriranjeDobavljaca formaAzuriranjeDobavljaca = new FormaAzuriranjeDobavljaca(odabraniDobavljac);
                formaAzuriranjeDobavljaca.Closed += (s, args) => this.Close();
                formaAzuriranjeDobavljaca.ShowDialog();
                OsvjeziDobavljaca();
            }
            else
            {
                MessageBox.Show("Morate odabrati dobavljača!", "Upozorenje!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnIzbrisiDobavljaca_Click(object sender, EventArgs e)
        {
            if (dgvPrikazDobavljaca.SelectedRows.Count > 0)
            {
                foreach (DataGridViewRow row in dgvPrikazDobavljaca.SelectedRows)
                {
                    Dobavljac dobavljac = row.DataBoundItem as Dobavljac;
                    dobavljac.BrisanjeDobavljaca();
                }

                MessageBox.Show("Uspješno brisanje dobavljača!", "Uspješno brisanje dobavljača!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Morate odabrati dobavljača!", "Upozorenje!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            OsvjeziDobavljaca();
        }
    }
}
