﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace skladiste
{
    public partial class FormaAzuriranjeNarudzbenice : Form
    {
        private Narudzbenica narudzbenicaZaIzmjenu = null;

        public FormaAzuriranjeNarudzbenice(Narudzbenica narudzbenica)
        {
            InitializeComponent();
            narudzbenicaZaIzmjenu = narudzbenica;
            dtpDatum.Enabled = false;
            label2.Enabled = false;
        }

        private void btnIzlaz_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormaPregledNarudzbenica formaPregledNarudzbenica = new FormaPregledNarudzbenica();
            formaPregledNarudzbenica.Closed += (s, args) => this.Close();
            formaPregledNarudzbenica.ShowDialog();
        }

        private void FormaAzuriranjeNarudzbenice_Load(object sender, EventArgs e)
        {
            outputId.Text = narudzbenicaZaIzmjenu.IdNarudzbenice.ToString();
            dtpDatum.Text = narudzbenicaZaIzmjenu.Datum.ToString();
            inputNapomena.Text = narudzbenicaZaIzmjenu.Napomena;
            inputUkupniIznos.Text = narudzbenicaZaIzmjenu.UkupniIznos.ToString();
        }

        private void btnAzuriraj_Click(object sender, EventArgs e)
        {
            DateTime datum = dtpDatum.Value;
            string napomena = inputNapomena.Text;
            float ukupniIznos = float.Parse(inputUkupniIznos.Text);

            if (String.IsNullOrWhiteSpace(dtpDatum.Text) || String.IsNullOrWhiteSpace(inputNapomena.Text) || String.IsNullOrWhiteSpace(inputUkupniIznos.Text))
            {
                MessageBox.Show("Unesite sve podatke za uspješno ažuriranje narudžbenice!", "Upozorenje!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                Narudzbenica narudzbenica = new Narudzbenica();
                narudzbenica.AzuriranjeNarudzbenice(narudzbenicaZaIzmjenu.IdNarudzbenice, datum, napomena, ukupniIznos);

                MessageBox.Show("Uspješno ste ažurirali narudžbenicu u bazi podataka!", "Uspješno ažuriranje narudžbenice!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.Hide();
                FormaPregledNarudzbenica formaPregledNarudzbenica = new FormaPregledNarudzbenica();
                formaPregledNarudzbenica.Closed += (s, args) => this.Close();
                formaPregledNarudzbenica.ShowDialog();
            }
        }
    }
}
