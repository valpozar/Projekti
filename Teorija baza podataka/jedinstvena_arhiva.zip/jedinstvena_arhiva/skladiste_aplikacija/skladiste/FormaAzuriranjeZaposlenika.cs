﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace skladiste
{
    public partial class FormaAzuriranjeZaposlenika : Form
    {
        private Korisnik azuriranjeZaposlenika = null;

        public FormaAzuriranjeZaposlenika(Korisnik zaposlenik)
        {
            InitializeComponent();
            azuriranjeZaposlenika = zaposlenik;
        }

        private void btnIzlaz_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormaZaposlenici formaZaposlenici = new FormaZaposlenici();
            formaZaposlenici.FormClosed += (s, args) => this.Close();
            formaZaposlenici.ShowDialog();
        }

        private void FormaAzuriranjeZaposlenika_Load(object sender, EventArgs e)
        {
            outputImePrezime.Text = azuriranjeZaposlenika.Ime + " " + azuriranjeZaposlenika.Prezime;
            inputEmail.Text = azuriranjeZaposlenika.Email;
            inputLozinka.Text = azuriranjeZaposlenika.Lozinka;
            inputAdresa.Text = azuriranjeZaposlenika.Adresa;
            inputKontakt.Text = azuriranjeZaposlenika.Kontakt;
        }

        private void btnAzuriraj_Click(object sender, EventArgs e)
        {
            azuriranjeZaposlenika.Email = inputEmail.Text;
            azuriranjeZaposlenika.Lozinka = inputLozinka.Text;
            azuriranjeZaposlenika.Adresa = inputAdresa.Text;
            azuriranjeZaposlenika.Kontakt = inputKontakt.Text;

            if (String.IsNullOrWhiteSpace(inputEmail.Text) || String.IsNullOrWhiteSpace(inputLozinka.Text) || String.IsNullOrWhiteSpace(inputAdresa.Text) || String.IsNullOrWhiteSpace(inputKontakt.Text))
            {
                MessageBox.Show("Morate unijeti sve podatke!", "Upozorenje!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                azuriranjeZaposlenika.SpremanjeZaposlenika();

                MessageBox.Show("Uspješno ažuriranje!", "Uspješno ažuriranje zaposlenika!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.Hide();
                FormaZaposlenici formaZaposlenci = new FormaZaposlenici();
                formaZaposlenci.Closed += (s, args) => this.Close();
                formaZaposlenci.ShowDialog();
            }
        }
    }
}
