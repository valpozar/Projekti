﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace skladiste
{
    public partial class FormaPrijava : Form
    {
        public static Korisnik Korisnik = null;
        private string email = "";
        private string lozinka = "";

        public FormaPrijava()
        {
            InitializeComponent();
            inputLozinka.PasswordChar = '*';
        }

        private void btnIzlaz_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormaPocetak pocetakForma = new FormaPocetak();
            pocetakForma.FormClosed += (s, args) => this.Close();
            pocetakForma.ShowDialog();
        }

        private void btnPrijaviSe_Click(object sender, EventArgs e)
        {
            email = inputEmail.Text;
            lozinka = inputLozinka.Text;
            Korisnik = Korisnik.DohvacanjeKorisnika(email);

            if (String.IsNullOrWhiteSpace(email) || String.IsNullOrWhiteSpace(lozinka))
            {
                MessageBox.Show("Morate unijeti sve podatke!", "Upozorenje!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (Korisnik == null)
            {
                MessageBox.Show("Uneseni email ne postoji u bazi podataka!", "Upozorenje!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (!lozinka.Equals(Korisnik.Lozinka))
            {
                MessageBox.Show("Lozinka nije ispravna!", "Upozorenje!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                this.Hide();
                FormaIzbornik formaIzbornik = new FormaIzbornik();
                formaIzbornik.Closed += (s, args) => this.Close();
                formaIzbornik.ShowDialog();
            }
        }
    }
}
