﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace skladiste
{
    public partial class FormaAzuriranjeArtikala : Form
    {
        private ArtiklUpravljanje azuriranjeArtikla = null;

        public FormaAzuriranjeArtikala(ArtiklUpravljanje artikl)
        {
            InitializeComponent();
            azuriranjeArtikla = artikl;
        }

        private void btnIzlaz_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormaArtikli formaArtikli = new FormaArtikli();
            formaArtikli.Closed += (s, args) => this.Close();
            formaArtikli.ShowDialog();
        }

        private void FormaAzuriranjeArtikala_Load(object sender, EventArgs e)
        {
            inputNaziv.Text = azuriranjeArtikla.Naziv;
            inputCijena.Text = azuriranjeArtikla.Cijena.ToString();
            inputJedinicaMjere.Text = azuriranjeArtikla.JedinicaMjere;
        }

        private void btnAzuriraj_Click(object sender, EventArgs e)
        {
            azuriranjeArtikla.Naziv = inputNaziv.Text;
            azuriranjeArtikla.Cijena = float.Parse(inputCijena.Text);
            azuriranjeArtikla.JedinicaMjere = inputJedinicaMjere.Text;

            if (String.IsNullOrWhiteSpace(inputNaziv.Text) || String.IsNullOrWhiteSpace(inputCijena.Text) || String.IsNullOrWhiteSpace(inputJedinicaMjere.Text))
            {
                MessageBox.Show("Morate unijeti sve podatke!", "Upozorenje!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                azuriranjeArtikla.SpremanjeArtikla();

                MessageBox.Show("Uspješno ažuriranje!", "Uspješno ažuriranje artikla!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.Hide();
                FormaArtikli formaArtikli = new FormaArtikli();
                formaArtikli.Closed += (s, args) => this.Close();
                formaArtikli.ShowDialog();
            }
        }
    }
}
