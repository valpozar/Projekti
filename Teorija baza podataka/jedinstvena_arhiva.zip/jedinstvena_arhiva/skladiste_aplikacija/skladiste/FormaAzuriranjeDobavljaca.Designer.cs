﻿namespace skladiste
{
    partial class FormaAzuriranjeDobavljaca
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAzuriraj = new System.Windows.Forms.Button();
            this.inputKontakt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.inputAdresa = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.inputNaziv = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnIzlaz = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnAzuriraj
            // 
            this.btnAzuriraj.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnAzuriraj.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnAzuriraj.Location = new System.Drawing.Point(146, 259);
            this.btnAzuriraj.Name = "btnAzuriraj";
            this.btnAzuriraj.Size = new System.Drawing.Size(106, 44);
            this.btnAzuriraj.TabIndex = 55;
            this.btnAzuriraj.Text = "AŽURIRAJ";
            this.btnAzuriraj.UseVisualStyleBackColor = false;
            this.btnAzuriraj.Click += new System.EventHandler(this.btnAzuriraj_Click);
            // 
            // inputKontakt
            // 
            this.inputKontakt.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.inputKontakt.Location = new System.Drawing.Point(178, 177);
            this.inputKontakt.Name = "inputKontakt";
            this.inputKontakt.Size = new System.Drawing.Size(140, 20);
            this.inputKontakt.TabIndex = 54;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(85, 177);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 13);
            this.label3.TabIndex = 53;
            this.label3.Text = "KONTAKT:";
            // 
            // inputAdresa
            // 
            this.inputAdresa.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.inputAdresa.Location = new System.Drawing.Point(178, 141);
            this.inputAdresa.Name = "inputAdresa";
            this.inputAdresa.Size = new System.Drawing.Size(140, 20);
            this.inputAdresa.TabIndex = 52;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(85, 141);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 51;
            this.label2.Text = "ADRESA:";
            // 
            // inputNaziv
            // 
            this.inputNaziv.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.inputNaziv.Location = new System.Drawing.Point(178, 105);
            this.inputNaziv.Name = "inputNaziv";
            this.inputNaziv.Size = new System.Drawing.Size(140, 20);
            this.inputNaziv.TabIndex = 50;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(85, 105);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 13);
            this.label1.TabIndex = 49;
            this.label1.Text = "NAZIV:";
            // 
            // btnIzlaz
            // 
            this.btnIzlaz.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnIzlaz.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIzlaz.Location = new System.Drawing.Point(10, 10);
            this.btnIzlaz.Name = "btnIzlaz";
            this.btnIzlaz.Size = new System.Drawing.Size(39, 25);
            this.btnIzlaz.TabIndex = 48;
            this.btnIzlaz.Text = "<--";
            this.btnIzlaz.UseVisualStyleBackColor = false;
            this.btnIzlaz.Click += new System.EventHandler(this.btnIzlaz_Click);
            // 
            // FormaAzuriranjeDobavljaca
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(399, 340);
            this.Controls.Add(this.btnAzuriraj);
            this.Controls.Add(this.inputKontakt);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.inputAdresa);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.inputNaziv);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnIzlaz);
            this.Name = "FormaAzuriranjeDobavljaca";
            this.Text = "Ažuriranje dobavljača";
            this.Load += new System.EventHandler(this.FormaAzuriranjeDobavljaca_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAzuriraj;
        private System.Windows.Forms.TextBox inputKontakt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox inputAdresa;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox inputNaziv;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnIzlaz;
    }
}