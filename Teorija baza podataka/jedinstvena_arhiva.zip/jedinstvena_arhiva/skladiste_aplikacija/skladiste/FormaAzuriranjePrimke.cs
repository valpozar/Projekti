﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace skladiste
{
    public partial class FormaAzuriranjePrimke : Form
    {
        private Primka primkaZaIzmjenu = null;

        public FormaAzuriranjePrimke(Primka primka)
        {
            InitializeComponent();
            primkaZaIzmjenu = primka;
            dtpDatum.Enabled = false;
            label2.Enabled = false;
        }

        private void btnIzlaz_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormaPregledPrimki formaPregledPrimki = new FormaPregledPrimki();
            formaPregledPrimki.Closed += (s, args) => this.Close();
            formaPregledPrimki.ShowDialog();
        }

        private void FormaAzuriranjePrimke_Load(object sender, EventArgs e)
        {
            outputId.Text = primkaZaIzmjenu.IdPrimke.ToString();
            dtpDatum.Text = primkaZaIzmjenu.Datum.ToString();
            inputBrojOtpremnice.Text = primkaZaIzmjenu.BrojOtpremnice.ToString();
            inputNapomena.Text = primkaZaIzmjenu.Napomena;
            inputUkupniIznos.Text = primkaZaIzmjenu.UkupniIznos.ToString();
            inputIdKorisnika.Text = primkaZaIzmjenu.IdKorisnika.ToString();
            inputIdNarudzbenice.Text = primkaZaIzmjenu.IdNarudzbenice.ToString();
        }

        private void btnAzuriraj_Click(object sender, EventArgs e)
        {
            DateTime datum = dtpDatum.Value;
            int brojOtpremnice = int.Parse(inputBrojOtpremnice.Text);
            string napomena = inputNapomena.Text;
            float ukupniIznos = float.Parse(inputUkupniIznos.Text);
            int idKorisnika = int.Parse(inputIdKorisnika.Text);
            int idNarudzbenice = int.Parse(inputIdNarudzbenice.Text);

            if (String.IsNullOrWhiteSpace(dtpDatum.Text) || String.IsNullOrWhiteSpace(inputBrojOtpremnice.Text) || String.IsNullOrWhiteSpace(inputNapomena.Text) || String.IsNullOrWhiteSpace(inputUkupniIznos.Text) || String.IsNullOrWhiteSpace(inputIdKorisnika.Text) || String.IsNullOrWhiteSpace(inputIdNarudzbenice.Text))
            {
                MessageBox.Show("Unesite sve podatke za uspješno ažuriranje primke!", "Upozorenje!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                Primka primka = new Primka();
                primka.AzuriranjePrimke(primkaZaIzmjenu.IdPrimke, datum, brojOtpremnice, napomena, ukupniIznos, idKorisnika, idNarudzbenice);

                MessageBox.Show("Uspješno ste ažurirali primku u bazi podataka!", "Uspješno ažuriranje primke!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.Hide();
                FormaPregledPrimki formaPregledPrimki = new FormaPregledPrimki();
                formaPregledPrimki.Closed += (s, args) => this.Close();
                formaPregledPrimki.ShowDialog();
            }
        }
    }
}
