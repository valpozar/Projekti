﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace skladiste
{
    public partial class FormaPocetak : Form
    {
        public FormaPocetak()
        {
            InitializeComponent();
        }

        private void btnPrijava_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormaPrijava formaPrijava = new FormaPrijava();
            formaPrijava.FormClosed += (s, args) => this.Close();
            formaPrijava.ShowDialog();
        }

        private void btnRegistracija_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormaRegistracija formaRegistracija = new FormaRegistracija();
            formaRegistracija.FormClosed += (s, args) => this.Close();
            formaRegistracija.ShowDialog();
        }
    }
}
