﻿namespace skladiste
{
    partial class FormaPregledPrimki
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.actionSvePrimke = new System.Windows.Forms.Button();
            this.actionAzurirajPrimku = new System.Windows.Forms.Button();
            this.actionObrisiPrimku = new System.Windows.Forms.Button();
            this.dgvStavkaPrimke = new System.Windows.Forms.DataGridView();
            this.actionPretrazi = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.inputIdPrimke = new System.Windows.Forms.TextBox();
            this.dgvPrimke = new System.Windows.Forms.DataGridView();
            this.btnIzlaz = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStavkaPrimke)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPrimke)).BeginInit();
            this.SuspendLayout();
            // 
            // actionSvePrimke
            // 
            this.actionSvePrimke.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.actionSvePrimke.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.actionSvePrimke.Location = new System.Drawing.Point(611, 24);
            this.actionSvePrimke.Name = "actionSvePrimke";
            this.actionSvePrimke.Size = new System.Drawing.Size(83, 23);
            this.actionSvePrimke.TabIndex = 64;
            this.actionSvePrimke.Text = "Sve primke";
            this.actionSvePrimke.UseVisualStyleBackColor = false;
            this.actionSvePrimke.Click += new System.EventHandler(this.actionSvePrimke_Click);
            // 
            // actionAzurirajPrimku
            // 
            this.actionAzurirajPrimku.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.actionAzurirajPrimku.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.actionAzurirajPrimku.Location = new System.Drawing.Point(733, 110);
            this.actionAzurirajPrimku.Name = "actionAzurirajPrimku";
            this.actionAzurirajPrimku.Size = new System.Drawing.Size(99, 32);
            this.actionAzurirajPrimku.TabIndex = 63;
            this.actionAzurirajPrimku.Text = "Ažuriraj primku";
            this.actionAzurirajPrimku.UseVisualStyleBackColor = false;
            this.actionAzurirajPrimku.Click += new System.EventHandler(this.actionAzurirajPrimku_Click);
            // 
            // actionObrisiPrimku
            // 
            this.actionObrisiPrimku.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.actionObrisiPrimku.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.actionObrisiPrimku.Location = new System.Drawing.Point(733, 62);
            this.actionObrisiPrimku.Name = "actionObrisiPrimku";
            this.actionObrisiPrimku.Size = new System.Drawing.Size(99, 32);
            this.actionObrisiPrimku.TabIndex = 62;
            this.actionObrisiPrimku.Text = "Obriši primku";
            this.actionObrisiPrimku.UseVisualStyleBackColor = false;
            this.actionObrisiPrimku.Click += new System.EventHandler(this.actionObrisiPrimku_Click);
            // 
            // dgvStavkaPrimke
            // 
            this.dgvStavkaPrimke.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvStavkaPrimke.BackgroundColor = System.Drawing.SystemColors.ScrollBar;
            this.dgvStavkaPrimke.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvStavkaPrimke.DefaultCellStyle = dataGridViewCellStyle1;
            this.dgvStavkaPrimke.Location = new System.Drawing.Point(21, 282);
            this.dgvStavkaPrimke.Name = "dgvStavkaPrimke";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvStavkaPrimke.RowHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvStavkaPrimke.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvStavkaPrimke.Size = new System.Drawing.Size(673, 198);
            this.dgvStavkaPrimke.TabIndex = 61;
            // 
            // actionPretrazi
            // 
            this.actionPretrazi.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.actionPretrazi.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.actionPretrazi.Location = new System.Drawing.Point(514, 24);
            this.actionPretrazi.Name = "actionPretrazi";
            this.actionPretrazi.Size = new System.Drawing.Size(75, 23);
            this.actionPretrazi.TabIndex = 58;
            this.actionPretrazi.Text = "Pretraži";
            this.actionPretrazi.UseVisualStyleBackColor = false;
            this.actionPretrazi.Click += new System.EventHandler(this.actionPretrazi_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label1.Location = new System.Drawing.Point(360, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 13);
            this.label1.TabIndex = 57;
            this.label1.Text = "ID primke:";
            // 
            // inputIdPrimke
            // 
            this.inputIdPrimke.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.inputIdPrimke.Location = new System.Drawing.Point(421, 26);
            this.inputIdPrimke.Name = "inputIdPrimke";
            this.inputIdPrimke.Size = new System.Drawing.Size(60, 20);
            this.inputIdPrimke.TabIndex = 56;
            // 
            // dgvPrimke
            // 
            this.dgvPrimke.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPrimke.BackgroundColor = System.Drawing.SystemColors.ScrollBar;
            this.dgvPrimke.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvPrimke.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgvPrimke.Location = new System.Drawing.Point(21, 62);
            this.dgvPrimke.Name = "dgvPrimke";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPrimke.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvPrimke.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPrimke.Size = new System.Drawing.Size(673, 198);
            this.dgvPrimke.TabIndex = 55;
            this.dgvPrimke.SelectionChanged += new System.EventHandler(this.dgvPrimke_SelectionChanged);
            // 
            // btnIzlaz
            // 
            this.btnIzlaz.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnIzlaz.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIzlaz.Location = new System.Drawing.Point(12, 12);
            this.btnIzlaz.Name = "btnIzlaz";
            this.btnIzlaz.Size = new System.Drawing.Size(39, 25);
            this.btnIzlaz.TabIndex = 71;
            this.btnIzlaz.Text = "<--";
            this.btnIzlaz.UseVisualStyleBackColor = false;
            this.btnIzlaz.Click += new System.EventHandler(this.btnIzlaz_Click);
            // 
            // FormaPregledPrimki
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(862, 521);
            this.Controls.Add(this.btnIzlaz);
            this.Controls.Add(this.actionSvePrimke);
            this.Controls.Add(this.actionAzurirajPrimku);
            this.Controls.Add(this.actionObrisiPrimku);
            this.Controls.Add(this.dgvStavkaPrimke);
            this.Controls.Add(this.actionPretrazi);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.inputIdPrimke);
            this.Controls.Add(this.dgvPrimke);
            this.Name = "FormaPregledPrimki";
            this.Text = "Pregled primki";
            this.Load += new System.EventHandler(this.FormaPregledPrimki_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvStavkaPrimke)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPrimke)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button actionSvePrimke;
        private System.Windows.Forms.Button actionAzurirajPrimku;
        private System.Windows.Forms.Button actionObrisiPrimku;
        private System.Windows.Forms.DataGridView dgvStavkaPrimke;
        private System.Windows.Forms.Button actionPretrazi;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox inputIdPrimke;
        private System.Windows.Forms.DataGridView dgvPrimke;
        private System.Windows.Forms.Button btnIzlaz;
    }
}