﻿namespace skladiste
{
    partial class FormaUnosArtikala
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnUnesi = new System.Windows.Forms.Button();
            this.inputJedinicaMjere = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.inputCijena = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.inputNaziv = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnIzlaz = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnUnesi
            // 
            this.btnUnesi.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnUnesi.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnUnesi.Location = new System.Drawing.Point(148, 261);
            this.btnUnesi.Name = "btnUnesi";
            this.btnUnesi.Size = new System.Drawing.Size(106, 44);
            this.btnUnesi.TabIndex = 73;
            this.btnUnesi.Text = "UNESI ARTIKL";
            this.btnUnesi.UseVisualStyleBackColor = false;
            this.btnUnesi.Click += new System.EventHandler(this.btnUnesi_Click);
            // 
            // inputJedinicaMjere
            // 
            this.inputJedinicaMjere.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.inputJedinicaMjere.Location = new System.Drawing.Point(216, 162);
            this.inputJedinicaMjere.Name = "inputJedinicaMjere";
            this.inputJedinicaMjere.Size = new System.Drawing.Size(140, 20);
            this.inputJedinicaMjere.TabIndex = 72;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(42, 169);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 13);
            this.label3.TabIndex = 71;
            this.label3.Text = "JEDINICA MJERE:";
            // 
            // inputCijena
            // 
            this.inputCijena.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.inputCijena.Location = new System.Drawing.Point(216, 127);
            this.inputCijena.Name = "inputCijena";
            this.inputCijena.Size = new System.Drawing.Size(140, 20);
            this.inputCijena.TabIndex = 70;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(42, 134);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 13);
            this.label2.TabIndex = 69;
            this.label2.Text = "CIJENA:";
            // 
            // inputNaziv
            // 
            this.inputNaziv.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.inputNaziv.Location = new System.Drawing.Point(216, 93);
            this.inputNaziv.Name = "inputNaziv";
            this.inputNaziv.Size = new System.Drawing.Size(140, 20);
            this.inputNaziv.TabIndex = 68;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(42, 93);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 13);
            this.label1.TabIndex = 67;
            this.label1.Text = "NAZIV:";
            // 
            // btnIzlaz
            // 
            this.btnIzlaz.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnIzlaz.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIzlaz.Location = new System.Drawing.Point(12, 12);
            this.btnIzlaz.Name = "btnIzlaz";
            this.btnIzlaz.Size = new System.Drawing.Size(39, 25);
            this.btnIzlaz.TabIndex = 66;
            this.btnIzlaz.Text = "<--";
            this.btnIzlaz.UseVisualStyleBackColor = false;
            this.btnIzlaz.Click += new System.EventHandler(this.btnIzlaz_Click);
            // 
            // FormaUnosArtikala
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(399, 340);
            this.Controls.Add(this.btnUnesi);
            this.Controls.Add(this.inputJedinicaMjere);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.inputCijena);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.inputNaziv);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnIzlaz);
            this.Name = "FormaUnosArtikala";
            this.Text = "Unos artikala";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnUnesi;
        private System.Windows.Forms.TextBox inputJedinicaMjere;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox inputCijena;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox inputNaziv;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnIzlaz;
    }
}