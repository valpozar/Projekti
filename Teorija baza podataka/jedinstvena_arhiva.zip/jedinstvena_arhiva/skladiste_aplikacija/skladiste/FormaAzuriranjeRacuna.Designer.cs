﻿namespace skladiste
{
    partial class FormaAzuriranjeRacuna
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dtpDatumDostave = new System.Windows.Forms.DateTimePicker();
            this.dtpDatumKreiranja = new System.Windows.Forms.DateTimePicker();
            this.inputIdKorisnika = new System.Windows.Forms.TextBox();
            this.inputNacinPlacanja = new System.Windows.Forms.TextBox();
            this.inputIznos = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.outputId = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnAzuriraj = new System.Windows.Forms.Button();
            this.btnIzlaz = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // dtpDatumDostave
            // 
            this.dtpDatumDostave.Location = new System.Drawing.Point(204, 230);
            this.dtpDatumDostave.Name = "dtpDatumDostave";
            this.dtpDatumDostave.Size = new System.Drawing.Size(146, 20);
            this.dtpDatumDostave.TabIndex = 93;
            // 
            // dtpDatumKreiranja
            // 
            this.dtpDatumKreiranja.Location = new System.Drawing.Point(204, 195);
            this.dtpDatumKreiranja.Name = "dtpDatumKreiranja";
            this.dtpDatumKreiranja.Size = new System.Drawing.Size(146, 20);
            this.dtpDatumKreiranja.TabIndex = 92;
            // 
            // inputIdKorisnika
            // 
            this.inputIdKorisnika.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.inputIdKorisnika.Location = new System.Drawing.Point(204, 160);
            this.inputIdKorisnika.Name = "inputIdKorisnika";
            this.inputIdKorisnika.Size = new System.Drawing.Size(148, 20);
            this.inputIdKorisnika.TabIndex = 89;
            // 
            // inputNacinPlacanja
            // 
            this.inputNacinPlacanja.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.inputNacinPlacanja.Location = new System.Drawing.Point(204, 127);
            this.inputNacinPlacanja.Name = "inputNacinPlacanja";
            this.inputNacinPlacanja.Size = new System.Drawing.Size(148, 20);
            this.inputNacinPlacanja.TabIndex = 88;
            // 
            // inputIznos
            // 
            this.inputIznos.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.inputIznos.Location = new System.Drawing.Point(204, 92);
            this.inputIznos.Name = "inputIznos";
            this.inputIznos.Size = new System.Drawing.Size(148, 20);
            this.inputIznos.TabIndex = 87;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.Location = new System.Drawing.Point(60, 160);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(95, 13);
            this.label6.TabIndex = 86;
            this.label6.Text = "ID KORISNIKA:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.Location = new System.Drawing.Point(60, 127);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(115, 13);
            this.label5.TabIndex = 85;
            this.label5.Text = "NAČIN PLAĆANJA:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(60, 92);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 13);
            this.label3.TabIndex = 83;
            this.label3.Text = "IZNOS:";
            // 
            // outputId
            // 
            this.outputId.AutoSize = true;
            this.outputId.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.outputId.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.outputId.Location = new System.Drawing.Point(201, 51);
            this.outputId.Name = "outputId";
            this.outputId.Size = new System.Drawing.Size(18, 13);
            this.outputId.TabIndex = 81;
            this.outputId.Text = "Id";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(97, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 13);
            this.label1.TabIndex = 80;
            this.label1.Text = "Račun:";
            // 
            // btnAzuriraj
            // 
            this.btnAzuriraj.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnAzuriraj.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnAzuriraj.Location = new System.Drawing.Point(153, 274);
            this.btnAzuriraj.Name = "btnAzuriraj";
            this.btnAzuriraj.Size = new System.Drawing.Size(106, 44);
            this.btnAzuriraj.TabIndex = 94;
            this.btnAzuriraj.Text = "AŽURIRAJ";
            this.btnAzuriraj.UseVisualStyleBackColor = false;
            this.btnAzuriraj.Click += new System.EventHandler(this.btnAzuriraj_Click);
            // 
            // btnIzlaz
            // 
            this.btnIzlaz.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnIzlaz.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIzlaz.Location = new System.Drawing.Point(12, 12);
            this.btnIzlaz.Name = "btnIzlaz";
            this.btnIzlaz.Size = new System.Drawing.Size(39, 25);
            this.btnIzlaz.TabIndex = 95;
            this.btnIzlaz.Text = "<--";
            this.btnIzlaz.UseVisualStyleBackColor = false;
            this.btnIzlaz.Click += new System.EventHandler(this.btnIzlaz_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(60, 195);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(128, 13);
            this.label2.TabIndex = 96;
            this.label2.Text = "DATUM KREIRANJA:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(60, 230);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(117, 13);
            this.label4.TabIndex = 97;
            this.label4.Text = "DATUM DOSTAVE:";
            // 
            // FormaAzuriranjeRacuna
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(399, 340);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnIzlaz);
            this.Controls.Add(this.btnAzuriraj);
            this.Controls.Add(this.dtpDatumDostave);
            this.Controls.Add(this.dtpDatumKreiranja);
            this.Controls.Add(this.inputIdKorisnika);
            this.Controls.Add(this.inputNacinPlacanja);
            this.Controls.Add(this.inputIznos);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.outputId);
            this.Controls.Add(this.label1);
            this.Name = "FormaAzuriranjeRacuna";
            this.Text = "Ažuriranje računa";
            this.Load += new System.EventHandler(this.FormaAzuriranjeRacuna_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dtpDatumDostave;
        private System.Windows.Forms.DateTimePicker dtpDatumKreiranja;
        private System.Windows.Forms.TextBox inputIdKorisnika;
        private System.Windows.Forms.TextBox inputNacinPlacanja;
        private System.Windows.Forms.TextBox inputIznos;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label outputId;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnAzuriraj;
        private System.Windows.Forms.Button btnIzlaz;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
    }
}