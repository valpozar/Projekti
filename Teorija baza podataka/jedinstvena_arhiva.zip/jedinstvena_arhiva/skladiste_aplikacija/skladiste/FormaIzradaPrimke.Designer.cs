﻿namespace skladiste
{
    partial class FormaIzradaPrimke
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.actionSviArtikli = new System.Windows.Forms.Button();
            this.actionPretraziArtikle = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.inputNazivArtikla = new System.Windows.Forms.TextBox();
            this.dgvArtikli = new System.Windows.Forms.DataGridView();
            this.dgvStavkaNarudzbenice = new System.Windows.Forms.DataGridView();
            this.tabControlPrimka = new System.Windows.Forms.TabControl();
            this.tabPagePrimka = new System.Windows.Forms.TabPage();
            this.dtpDatum = new System.Windows.Forms.DateTimePicker();
            this.cmbIdPrimke = new System.Windows.Forms.ComboBox();
            this.inputIdArtikla = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.inputKolicina = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.actionDodajStavke = new System.Windows.Forms.Button();
            this.inputUkupanIznos = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.inputBrojOtpremnice = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.inputNapomena = new System.Windows.Forms.TextBox();
            this.inputIdNarudzbeniceUnos = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.actionSveNarudzbenice = new System.Windows.Forms.Button();
            this.actionIzradiPrimku = new System.Windows.Forms.Button();
            this.actionPretrazi = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvNarudzbenice = new System.Windows.Forms.DataGridView();
            this.inputIdNarudzbenice = new System.Windows.Forms.TextBox();
            this.btnIzlaz = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.lblKolicina = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvArtikli)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStavkaNarudzbenice)).BeginInit();
            this.tabControlPrimka.SuspendLayout();
            this.tabPagePrimka.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNarudzbenice)).BeginInit();
            this.SuspendLayout();
            // 
            // actionSviArtikli
            // 
            this.actionSviArtikli.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.actionSviArtikli.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.actionSviArtikli.Location = new System.Drawing.Point(905, 262);
            this.actionSviArtikli.Name = "actionSviArtikli";
            this.actionSviArtikli.Size = new System.Drawing.Size(69, 23);
            this.actionSviArtikli.TabIndex = 82;
            this.actionSviArtikli.Text = "Svi artikli";
            this.actionSviArtikli.UseVisualStyleBackColor = false;
            this.actionSviArtikli.Click += new System.EventHandler(this.actionSviArtikli_Click);
            // 
            // actionPretraziArtikle
            // 
            this.actionPretraziArtikle.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.actionPretraziArtikle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.actionPretraziArtikle.Location = new System.Drawing.Point(815, 262);
            this.actionPretraziArtikle.Name = "actionPretraziArtikle";
            this.actionPretraziArtikle.Size = new System.Drawing.Size(75, 23);
            this.actionPretraziArtikle.TabIndex = 81;
            this.actionPretraziArtikle.Text = "Pretraži";
            this.actionPretraziArtikle.UseVisualStyleBackColor = false;
            this.actionPretraziArtikle.Click += new System.EventHandler(this.actionPretraziArtikle_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label10.Location = new System.Drawing.Point(601, 267);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(68, 13);
            this.label10.TabIndex = 80;
            this.label10.Text = "Naziv artikla:";
            // 
            // inputNazivArtikla
            // 
            this.inputNazivArtikla.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.inputNazivArtikla.Location = new System.Drawing.Point(675, 263);
            this.inputNazivArtikla.Name = "inputNazivArtikla";
            this.inputNazivArtikla.Size = new System.Drawing.Size(115, 20);
            this.inputNazivArtikla.TabIndex = 79;
            // 
            // dgvArtikli
            // 
            this.dgvArtikli.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvArtikli.BackgroundColor = System.Drawing.SystemColors.ScrollBar;
            this.dgvArtikli.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvArtikli.DefaultCellStyle = dataGridViewCellStyle1;
            this.dgvArtikli.Location = new System.Drawing.Point(641, 296);
            this.dgvArtikli.Name = "dgvArtikli";
            this.dgvArtikli.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvArtikli.Size = new System.Drawing.Size(296, 150);
            this.dgvArtikli.TabIndex = 78;
            this.dgvArtikli.SelectionChanged += new System.EventHandler(this.dgvArtikli_SelectionChanged);
            // 
            // dgvStavkaNarudzbenice
            // 
            this.dgvStavkaNarudzbenice.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvStavkaNarudzbenice.BackgroundColor = System.Drawing.SystemColors.ScrollBar;
            this.dgvStavkaNarudzbenice.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvStavkaNarudzbenice.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvStavkaNarudzbenice.Location = new System.Drawing.Point(641, 53);
            this.dgvStavkaNarudzbenice.Name = "dgvStavkaNarudzbenice";
            this.dgvStavkaNarudzbenice.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvStavkaNarudzbenice.Size = new System.Drawing.Size(296, 150);
            this.dgvStavkaNarudzbenice.TabIndex = 77;
            // 
            // tabControlPrimka
            // 
            this.tabControlPrimka.Controls.Add(this.tabPagePrimka);
            this.tabControlPrimka.Location = new System.Drawing.Point(25, 221);
            this.tabControlPrimka.Name = "tabControlPrimka";
            this.tabControlPrimka.SelectedIndex = 0;
            this.tabControlPrimka.Size = new System.Drawing.Size(526, 244);
            this.tabControlPrimka.TabIndex = 76;
            // 
            // tabPagePrimka
            // 
            this.tabPagePrimka.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.tabPagePrimka.Controls.Add(this.dtpDatum);
            this.tabPagePrimka.Controls.Add(this.cmbIdPrimke);
            this.tabPagePrimka.Controls.Add(this.inputIdArtikla);
            this.tabPagePrimka.Controls.Add(this.label6);
            this.tabPagePrimka.Controls.Add(this.inputKolicina);
            this.tabPagePrimka.Controls.Add(this.label2);
            this.tabPagePrimka.Controls.Add(this.label5);
            this.tabPagePrimka.Controls.Add(this.actionDodajStavke);
            this.tabPagePrimka.Controls.Add(this.inputUkupanIznos);
            this.tabPagePrimka.Controls.Add(this.label9);
            this.tabPagePrimka.Controls.Add(this.inputBrojOtpremnice);
            this.tabPagePrimka.Controls.Add(this.label3);
            this.tabPagePrimka.Controls.Add(this.inputNapomena);
            this.tabPagePrimka.Controls.Add(this.inputIdNarudzbeniceUnos);
            this.tabPagePrimka.Controls.Add(this.label7);
            this.tabPagePrimka.Controls.Add(this.label4);
            this.tabPagePrimka.Location = new System.Drawing.Point(4, 22);
            this.tabPagePrimka.Name = "tabPagePrimka";
            this.tabPagePrimka.Padding = new System.Windows.Forms.Padding(3);
            this.tabPagePrimka.Size = new System.Drawing.Size(518, 218);
            this.tabPagePrimka.TabIndex = 0;
            this.tabPagePrimka.Text = "Primka";
            // 
            // dtpDatum
            // 
            this.dtpDatum.CalendarMonthBackground = System.Drawing.SystemColors.ScrollBar;
            this.dtpDatum.Location = new System.Drawing.Point(118, 154);
            this.dtpDatum.Name = "dtpDatum";
            this.dtpDatum.Size = new System.Drawing.Size(148, 20);
            this.dtpDatum.TabIndex = 127;
            this.dtpDatum.Visible = false;
            // 
            // cmbIdPrimke
            // 
            this.cmbIdPrimke.FormattingEnabled = true;
            this.cmbIdPrimke.Location = new System.Drawing.Point(384, 53);
            this.cmbIdPrimke.Name = "cmbIdPrimke";
            this.cmbIdPrimke.Size = new System.Drawing.Size(128, 21);
            this.cmbIdPrimke.TabIndex = 76;
            // 
            // inputIdArtikla
            // 
            this.inputIdArtikla.Location = new System.Drawing.Point(384, 120);
            this.inputIdArtikla.Name = "inputIdArtikla";
            this.inputIdArtikla.Size = new System.Drawing.Size(128, 20);
            this.inputIdArtikla.TabIndex = 75;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(288, 124);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 13);
            this.label6.TabIndex = 74;
            this.label6.Text = "ID artikla:";
            // 
            // inputKolicina
            // 
            this.inputKolicina.Location = new System.Drawing.Point(384, 86);
            this.inputKolicina.Name = "inputKolicina";
            this.inputKolicina.Size = new System.Drawing.Size(128, 20);
            this.inputKolicina.TabIndex = 73;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(288, 88);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 72;
            this.label2.Text = "Količina:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(285, 56);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 13);
            this.label5.TabIndex = 70;
            this.label5.Text = "ID primke:";
            // 
            // actionDodajStavke
            // 
            this.actionDodajStavke.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.actionDodajStavke.Location = new System.Drawing.Point(366, 171);
            this.actionDodajStavke.Name = "actionDodajStavke";
            this.actionDodajStavke.Size = new System.Drawing.Size(99, 32);
            this.actionDodajStavke.TabIndex = 58;
            this.actionDodajStavke.Text = "Dodaj stavku";
            this.actionDodajStavke.UseVisualStyleBackColor = true;
            this.actionDodajStavke.Click += new System.EventHandler(this.actionDodajStavke_Click);
            // 
            // inputUkupanIznos
            // 
            this.inputUkupanIznos.Location = new System.Drawing.Point(118, 124);
            this.inputUkupanIznos.Name = "inputUkupanIznos";
            this.inputUkupanIznos.Size = new System.Drawing.Size(128, 20);
            this.inputUkupanIznos.TabIndex = 69;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(16, 127);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(75, 13);
            this.label9.TabIndex = 68;
            this.label9.Text = "Ukupan iznos:";
            // 
            // inputBrojOtpremnice
            // 
            this.inputBrojOtpremnice.Location = new System.Drawing.Point(118, 91);
            this.inputBrojOtpremnice.Name = "inputBrojOtpremnice";
            this.inputBrojOtpremnice.Size = new System.Drawing.Size(128, 20);
            this.inputBrojOtpremnice.TabIndex = 67;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 94);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 13);
            this.label3.TabIndex = 66;
            this.label3.Text = "Broj otpremnice:";
            // 
            // inputNapomena
            // 
            this.inputNapomena.Location = new System.Drawing.Point(118, 60);
            this.inputNapomena.Name = "inputNapomena";
            this.inputNapomena.Size = new System.Drawing.Size(128, 20);
            this.inputNapomena.TabIndex = 58;
            // 
            // inputIdNarudzbeniceUnos
            // 
            this.inputIdNarudzbeniceUnos.Location = new System.Drawing.Point(118, 29);
            this.inputIdNarudzbeniceUnos.Name = "inputIdNarudzbeniceUnos";
            this.inputIdNarudzbeniceUnos.Size = new System.Drawing.Size(128, 20);
            this.inputIdNarudzbeniceUnos.TabIndex = 55;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(16, 64);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 13);
            this.label7.TabIndex = 52;
            this.label7.Text = "Napomena:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(16, 29);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(88, 13);
            this.label4.TabIndex = 49;
            this.label4.Text = "ID narudžbenice:";
            // 
            // actionSveNarudzbenice
            // 
            this.actionSveNarudzbenice.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.actionSveNarudzbenice.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.actionSveNarudzbenice.Location = new System.Drawing.Point(312, 14);
            this.actionSveNarudzbenice.Name = "actionSveNarudzbenice";
            this.actionSveNarudzbenice.Size = new System.Drawing.Size(125, 23);
            this.actionSveNarudzbenice.TabIndex = 75;
            this.actionSveNarudzbenice.Text = "Sve narudžbenice";
            this.actionSveNarudzbenice.UseVisualStyleBackColor = false;
            this.actionSveNarudzbenice.Click += new System.EventHandler(this.actionSveNarudzbenice_Click);
            // 
            // actionIzradiPrimku
            // 
            this.actionIzradiPrimku.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.actionIzradiPrimku.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.actionIzradiPrimku.Location = new System.Drawing.Point(116, 471);
            this.actionIzradiPrimku.Name = "actionIzradiPrimku";
            this.actionIzradiPrimku.Size = new System.Drawing.Size(99, 32);
            this.actionIzradiPrimku.TabIndex = 73;
            this.actionIzradiPrimku.Text = "Izradi primku";
            this.actionIzradiPrimku.UseVisualStyleBackColor = false;
            this.actionIzradiPrimku.Click += new System.EventHandler(this.actionIzradiPrimku_Click);
            // 
            // actionPretrazi
            // 
            this.actionPretrazi.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.actionPretrazi.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.actionPretrazi.Location = new System.Drawing.Point(200, 14);
            this.actionPretrazi.Name = "actionPretrazi";
            this.actionPretrazi.Size = new System.Drawing.Size(75, 23);
            this.actionPretrazi.TabIndex = 72;
            this.actionPretrazi.Text = "Pretraži";
            this.actionPretrazi.UseVisualStyleBackColor = false;
            this.actionPretrazi.Click += new System.EventHandler(this.actionPretrazi_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label1.Location = new System.Drawing.Point(22, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 13);
            this.label1.TabIndex = 71;
            this.label1.Text = "ID narudžbenice:";
            // 
            // dgvNarudzbenice
            // 
            this.dgvNarudzbenice.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvNarudzbenice.BackgroundColor = System.Drawing.SystemColors.ScrollBar;
            this.dgvNarudzbenice.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvNarudzbenice.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgvNarudzbenice.Location = new System.Drawing.Point(25, 53);
            this.dgvNarudzbenice.Name = "dgvNarudzbenice";
            this.dgvNarudzbenice.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvNarudzbenice.Size = new System.Drawing.Size(469, 150);
            this.dgvNarudzbenice.TabIndex = 70;
            this.dgvNarudzbenice.SelectionChanged += new System.EventHandler(this.dgvNarudzbenice_SelectionChanged);
            // 
            // inputIdNarudzbenice
            // 
            this.inputIdNarudzbenice.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.inputIdNarudzbenice.Location = new System.Drawing.Point(116, 16);
            this.inputIdNarudzbenice.Name = "inputIdNarudzbenice";
            this.inputIdNarudzbenice.Size = new System.Drawing.Size(55, 20);
            this.inputIdNarudzbenice.TabIndex = 69;
            // 
            // btnIzlaz
            // 
            this.btnIzlaz.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnIzlaz.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIzlaz.Location = new System.Drawing.Point(970, 7);
            this.btnIzlaz.Name = "btnIzlaz";
            this.btnIzlaz.Size = new System.Drawing.Size(39, 25);
            this.btnIzlaz.TabIndex = 83;
            this.btnIzlaz.Text = "<--";
            this.btnIzlaz.UseVisualStyleBackColor = false;
            this.btnIzlaz.Click += new System.EventHandler(this.btnIzlaz_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label11.Location = new System.Drawing.Point(648, 37);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(156, 13);
            this.label11.TabIndex = 84;
            this.label11.Text = "Stavke odabrane narudžbenice";
            // 
            // lblKolicina
            // 
            this.lblKolicina.AutoSize = true;
            this.lblKolicina.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.lblKolicina.Location = new System.Drawing.Point(638, 462);
            this.lblKolicina.Name = "lblKolicina";
            this.lblKolicina.Size = new System.Drawing.Size(197, 13);
            this.lblKolicina.TabIndex = 85;
            this.lblKolicina.Text = "Količina na skladištu (odabranog artikla):";
            // 
            // FormaIzradaPrimke
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(1021, 514);
            this.Controls.Add(this.lblKolicina);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.btnIzlaz);
            this.Controls.Add(this.actionSviArtikli);
            this.Controls.Add(this.actionPretraziArtikle);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.inputNazivArtikla);
            this.Controls.Add(this.dgvArtikli);
            this.Controls.Add(this.dgvStavkaNarudzbenice);
            this.Controls.Add(this.tabControlPrimka);
            this.Controls.Add(this.actionSveNarudzbenice);
            this.Controls.Add(this.actionIzradiPrimku);
            this.Controls.Add(this.actionPretrazi);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgvNarudzbenice);
            this.Controls.Add(this.inputIdNarudzbenice);
            this.Name = "FormaIzradaPrimke";
            this.Text = "Izrada primke";
            this.Load += new System.EventHandler(this.FormaIzradaPrimke_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvArtikli)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStavkaNarudzbenice)).EndInit();
            this.tabControlPrimka.ResumeLayout(false);
            this.tabPagePrimka.ResumeLayout(false);
            this.tabPagePrimka.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNarudzbenice)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button actionSviArtikli;
        private System.Windows.Forms.Button actionPretraziArtikle;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox inputNazivArtikla;
        private System.Windows.Forms.DataGridView dgvArtikli;
        private System.Windows.Forms.DataGridView dgvStavkaNarudzbenice;
        private System.Windows.Forms.TabControl tabControlPrimka;
        private System.Windows.Forms.TabPage tabPagePrimka;
        private System.Windows.Forms.ComboBox cmbIdPrimke;
        private System.Windows.Forms.TextBox inputIdArtikla;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox inputKolicina;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button actionDodajStavke;
        private System.Windows.Forms.TextBox inputUkupanIznos;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox inputBrojOtpremnice;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox inputNapomena;
        private System.Windows.Forms.TextBox inputIdNarudzbeniceUnos;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button actionSveNarudzbenice;
        private System.Windows.Forms.Button actionIzradiPrimku;
        private System.Windows.Forms.Button actionPretrazi;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvNarudzbenice;
        private System.Windows.Forms.TextBox inputIdNarudzbenice;
        private System.Windows.Forms.Button btnIzlaz;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblKolicina;
        private System.Windows.Forms.DateTimePicker dtpDatum;
    }
}