﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;

namespace skladiste
{
    class DB
    {
        private static DB instance;
        private string connectionString;
        private NpgsqlConnection connection;

        public static DB Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new DB();
                }
                return instance;
            }
        }

        public string ConnectionString
        {
            get
            {
                return connectionString;
            }
            private set
            {
                if (connectionString != value)
                {
                    connectionString = value;
                }
            }
        }

        public NpgsqlConnection Connection
        {
            get
            {
                return connection;
            }
            private set
            {
                if (connection != value)
                {
                    connection = value;
                }
            }
        }

        private DB()
        {
            ConnectionString = Properties.Settings.Default.ConnectionSkladiste; 
            Connection = new NpgsqlConnection(ConnectionString);
            Connection.Open();
        }

        ~DB()
        {
            Connection = null;
        }

        public NpgsqlDataReader DohvatiDataReader(string sqlUpit)
        {
            NpgsqlCommand command = new NpgsqlCommand(sqlUpit, Connection);
            return command.ExecuteReader();
        }

        public object DohvatiVrijednost(string sqlUpit)
        {
            NpgsqlCommand command = new NpgsqlCommand(sqlUpit, Connection);
            return command.ExecuteScalar();
        }

        public int IzvrsiUpit(string sqlUpit)
        {
            NpgsqlCommand command = new NpgsqlCommand(sqlUpit, Connection);
            return command.ExecuteNonQuery();
        }
    }
}
