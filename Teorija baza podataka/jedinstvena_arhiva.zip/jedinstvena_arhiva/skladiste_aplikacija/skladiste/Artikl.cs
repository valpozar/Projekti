﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;

namespace skladiste
{
    public class Artikl
    {
        public string Naziv { get; set; }
        public float Cijena { get; set; }
        public string JedinicaMjere { get; set; }

        public Artikl(string naziv, float cijena, string jedinica_mjere)
        {
            Naziv = naziv;
            Cijena = cijena;
            JedinicaMjere = jedinica_mjere;
        }

        public Artikl(DbDataReader podaci)
        {

            if (podaci != null)
            {
                Naziv = podaci["naziv"].ToString();
                Cijena = float.Parse(podaci["cijena"].ToString());
                JedinicaMjere = podaci["jedinica_mjere"].ToString();
            }
        }

        public static List<Artikl> DohvacanjeArtikala()
        {
            List<Artikl> lista = new List<Artikl>();
            string sqlUpit = "SELECT id_artikla, naziv, cijena, jedinica_mjere FROM artikl";
            DbDataReader dr = DB.Instance.DohvatiDataReader(sqlUpit);
            while (dr.Read())
            {
                Artikl artikl = new Artikl(dr);
                lista.Add(artikl);
            }
            dr.Close();
            return lista;
        }

        public static List<Artikl> DohvacanjePretrazenihArtikala(string pretraga)
        {
            List<Artikl> lista = new List<Artikl>();
            string sqlUpit = "SELECT id_artikla, naziv, cijena, jedinica_mjere FROM artikl WHERE naziv LIKE '%" + pretraga + "%'";
            DbDataReader dr = DB.Instance.DohvatiDataReader(sqlUpit);
            while (dr.Read())
            {
                Artikl artikl = new Artikl(dr);
                lista.Add(artikl);
            }
            dr.Close();
            return lista;
        }
    }
}
