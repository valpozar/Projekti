﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Common;

namespace skladiste
{
    public class Primka
    {
        public int IdPrimke { get; set; }
        public DateTime Datum { get; set; }
        public int BrojOtpremnice { get; set; }
        public string Napomena { get; set; }
        public float UkupniIznos { get; set; }
        public int IdKorisnika { get; set; }
        public int IdNarudzbenice { get; set; }

        public Primka()
        {

        }

        public Primka(DbDataReader podaci)
        {
            if (podaci != null)
            {
                IdPrimke = int.Parse(podaci["id_primke"].ToString());
                Datum = DateTime.Parse(podaci["datum"].ToString());
                BrojOtpremnice = int.Parse(podaci["broj_otpremnice"].ToString());
                Napomena = podaci["napomena"].ToString();
                UkupniIznos = float.Parse(podaci["ukupan_iznos"].ToString());
                IdKorisnika = int.Parse(podaci["id_korisnika"].ToString());
                IdNarudzbenice = int.Parse(podaci["id_narudzbenice"].ToString());
            }
        }

        public static List<Primka> DohvatiPrimke()
        {
            List<Primka> lista = new List<Primka>();
            string sqlUpit = "SELECT * FROM primka";
            DbDataReader dr = DB.Instance.DohvatiDataReader(sqlUpit);
            while (dr.Read())
            {

                Primka primka = new Primka(dr);
                lista.Add(primka);
            }
            dr.Close();
            return lista;
        }

        public static List<Primka> DohvatiPretrazenePrimke(int pretraga)
        {
            List<Primka> lista = new List<Primka>();
            string sqlUpit = "SELECT * FROM primka WHERE id_primke = " + pretraga;
            DbDataReader dr = DB.Instance.DohvatiDataReader(sqlUpit);
            while (dr.Read())
            {

                Primka primka = new Primka(dr);
                lista.Add(primka);
            }
            dr.Close();
            return lista;
        }

        public void BrisanjePrimke()
        {
            string sqlUpit = "DELETE FROM primka WHERE  id_primke = " + this.IdPrimke;
            DB.Instance.IzvrsiUpit(sqlUpit);
        }

        public void AzuriranjePrimke(int id, DateTime datum, int brojOtpremnice, string napomena, float ukupniIznos, int idKorisnika, int idNarudzbenice)
        {
            string sqlUpit = "UPDATE primka SET datum = default, broj_otpremnice = '" + brojOtpremnice + "' , napomena = '" + napomena + "' , ukupan_iznos = '" + ukupniIznos + "' , id_korisnika = '" + idKorisnika + "' , id_narudzbenice = '" + idNarudzbenice + "'WHERE id_primke = " + id;
            DB.Instance.IzvrsiUpit(sqlUpit);
        }

        public void DodavanjePrimke(DateTime datum, int brojOtpremnice, string napomena, float ukupniIznos, int idKorisnika, int idNarudzbenice)
        {
            string sqlUpit = "INSERT INTO primka (datum, broj_otpremnice, napomena, ukupan_iznos, id_korisnika, id_narudzbenice) VALUES (default, '" + brojOtpremnice + "','" + napomena + "','" + ukupniIznos + "','" + idKorisnika + "','" + idNarudzbenice + "')";
            DB.Instance.IzvrsiUpit(sqlUpit);
        }
    }
}
