﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace skladiste
{
    public partial class FormaUnosZaposlenika : Form
    {
        private Korisnik unosZaposlenika = null;
        private string ime = "";
        private string prezime = "";
        private string email = "";
        private string lozinka = "";
        private string potvrdaLozinke = "";
        private string adresa = "";
        private string kontakt = "";

        public FormaUnosZaposlenika()
        {
            InitializeComponent();
            inputLozinka.PasswordChar = '*';
            inputPotvrdaLozinke.PasswordChar = '*';
        }

        private void btnIzlaz_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormaZaposlenici formaZaposlenici = new FormaZaposlenici();
            formaZaposlenici.FormClosed += (s, args) => this.Close();
            formaZaposlenici.ShowDialog();
        }

        private void btnUnesiZaposlenika_Click(object sender, EventArgs e)
        {
            ime = inputIme.Text;
            prezime = inputPrezime.Text;
            email = inputEmail.Text;
            lozinka = inputLozinka.Text;
            potvrdaLozinke = inputPotvrdaLozinke.Text;
            adresa = inputAdresa.Text;
            kontakt = inputKontakt.Text;

            int postojiEmail = 0;

            if (String.IsNullOrWhiteSpace(ime) || String.IsNullOrWhiteSpace(prezime) || String.IsNullOrWhiteSpace(email) || String.IsNullOrWhiteSpace(lozinka) || String.IsNullOrWhiteSpace(potvrdaLozinke) || String.IsNullOrWhiteSpace(adresa) || String.IsNullOrWhiteSpace(kontakt))
            {
                MessageBox.Show("Morate unijeti sve podatke!", "Upozorenje!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (lozinka.Equals(potvrdaLozinke) == false)
            {
                MessageBox.Show("Lozinka i potvrda lozinke moraju biti jednake!", "Upozorenje!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                postojiEmail = Korisnik.ProvjeraEmaila(email);
                if (postojiEmail == 1)
                {
                    MessageBox.Show("Uneseni email već postoji!", "Upozorenje!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    unosZaposlenika = new Korisnik(ime, prezime, email, lozinka, adresa, kontakt);
                    unosZaposlenika.SpremanjeZaposlenika();

                    MessageBox.Show("Uspješan unos zaposlenika!", "Uspješno dodavanje zaposlenika!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    this.Hide();
                    FormaZaposlenici formaZaposlenici = new FormaZaposlenici();
                    formaZaposlenici.Closed += (s, args) => this.Close();
                    formaZaposlenici.ShowDialog();
                }
            }
        }
    }
}
