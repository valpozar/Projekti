﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Common;

namespace skladiste
{
    public class StavkaPrimke
    {
        public ArtiklUpravljanje NazivArtikla { get; set; }
        public float Cijena { get; set; }
        public int Kolicina { get; set; }
        public Primka Pri;
        public int IdPrimke;
        public int IdArtikla;

        public StavkaPrimke()
        {

        }

        public StavkaPrimke(int kolicina, int idprimke, int idartikla)
        {
            Kolicina = kolicina;
            IdPrimke = idprimke;
            IdArtikla = idartikla;
        }

        public StavkaPrimke(DbDataReader podaci)
        {
            if (podaci != null)
            {
                Kolicina = int.Parse(podaci["kolicina"].ToString());
                Pri = new Primka();
                Pri.IdPrimke = int.Parse(podaci["id_primke"].ToString());
                NazivArtikla = new ArtiklUpravljanje();
                NazivArtikla.IdArtikla = int.Parse(podaci["id_artikla"].ToString());
                NazivArtikla.Naziv = podaci["naziv"].ToString();
                Cijena = float.Parse(podaci["cijena"].ToString());
            }
        }

        public List<StavkaPrimke> DohvatiStavkePrimke(int id)
        {
            List<StavkaPrimke> lista = new List<StavkaPrimke>();
            string sqlUpit = "SELECT p.id_primke, a.id_artikla, s.kolicina, a.naziv, a.cijena FROM primka p JOIN stavke_primke s ON p.id_primke=s.id_primke JOIN artikl a ON s.id_artikla=a.id_artikla WHERE s.id_primke = " + id;
            DbDataReader dr = DB.Instance.DohvatiDataReader(sqlUpit);
            while (dr.Read())
            {

                StavkaPrimke stavkaPrimke = new StavkaPrimke(dr);
                lista.Add(stavkaPrimke);
            }
            dr.Close();
            return lista;
        }

        public static int DohvatiKolicinuSaSkladista(int id)
        {
            int kolicina = 0;
            string sqlUpit = "SELECT s.kolicina FROM skladiste s WHERE s.id_artikla = " + id;
            DbDataReader dr = DB.Instance.DohvatiDataReader(sqlUpit);
            while (dr.Read())
            {
                kolicina = int.Parse(dr["kolicina"].ToString());
            }
            dr.Close();
            return kolicina;
        }

        public void DodajStavkuPrimke()
        {
            string sqlUpit = "INSERT INTO stavke_primke (kolicina, id_artikla, id_primke) VALUES ('" + this.Kolicina + "','" + this.IdArtikla + "','" + this.IdPrimke + "')";
            DB.Instance.IzvrsiUpit(sqlUpit);
        }

        public override string ToString()
        {
            return Kolicina.ToString();
        }
    }
}
