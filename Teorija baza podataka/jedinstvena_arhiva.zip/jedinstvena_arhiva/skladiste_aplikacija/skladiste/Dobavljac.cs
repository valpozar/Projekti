﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;

namespace skladiste
{
    public class Dobavljac
    {
        public int IDDobavljaca { get; set; }
        public string Naziv { get; set; }
        public string Adresa { get; set; }
        public string Kontakt { get; set; }

        public Dobavljac(string naziv, string adresa, string kontakt)
        {
            Naziv = naziv;
            Adresa = adresa;
            Kontakt = kontakt;
        }

        public Dobavljac(DbDataReader dr)
        {
            if (dr != null)
            {
                IDDobavljaca = int.Parse(dr["id_dobavljaca"].ToString());
                Naziv = dr["naziv"].ToString();
                Adresa = dr["adresa"].ToString();
                Kontakt = dr["kontakt"].ToString();
            }
        }

        public static List<Dobavljac> DohvacanjeDobavljaca(string kljucnaRijec)
        {
            List<Dobavljac> listaDobavljaca = new List<Dobavljac>();
            string sqlUpit = "SELECT * FROM dobavljac WHERE naziv LIKE '%" + kljucnaRijec + "%'";
            DbDataReader dr = DB.Instance.DohvatiDataReader(sqlUpit);

            while (dr.Read())
            {
                Dobavljac dobavljac = new Dobavljac(dr);
                listaDobavljaca.Add(dobavljac);
            }
            dr.Close();
            return listaDobavljaca;
        }

        public static int ProvjeraNaziva(string naziv)
        {
            string sqlUpit = "SELECT COUNT(*) FROM dobavljac WHERE naziv = '" + naziv + "'";

            return Convert.ToInt32(DB.Instance.DohvatiVrijednost(sqlUpit));
        }

        public int SpremanjeDobavljaca()
        {
            string sqlUpit = "";
            if (IDDobavljaca == 0)
            {
                sqlUpit = "INSERT INTO dobavljac (id_dobavljaca, naziv, adresa, kontakt) VALUES (default, '" + Naziv + "','" + Adresa + "','" + Kontakt + "')";
            }
            else
            {
                sqlUpit = "UPDATE dobavljac SET naziv = '" + Naziv + "', adresa = '" + Adresa + "', kontakt = '" + Kontakt + "' WHERE id_dobavljaca = " + IDDobavljaca;
            }
            return DB.Instance.IzvrsiUpit(sqlUpit);
        }

        public int BrisanjeDobavljaca()
        {
            string sqlDelete = "DELETE FROM dobavljac WHERE id_dobavljaca = " + IDDobavljaca;
            return DB.Instance.IzvrsiUpit(sqlDelete);
        }
    }
}
