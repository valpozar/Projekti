﻿namespace skladiste
{
    partial class FormaStanjeNaSkladistu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnIzlaz = new System.Windows.Forms.Button();
            this.dgvPrikazStanjaNaSkladistu = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPrikazStanjaNaSkladistu)).BeginInit();
            this.SuspendLayout();
            // 
            // btnIzlaz
            // 
            this.btnIzlaz.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnIzlaz.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnIzlaz.Location = new System.Drawing.Point(9, 9);
            this.btnIzlaz.Name = "btnIzlaz";
            this.btnIzlaz.Size = new System.Drawing.Size(39, 25);
            this.btnIzlaz.TabIndex = 90;
            this.btnIzlaz.Text = "<--";
            this.btnIzlaz.UseVisualStyleBackColor = false;
            this.btnIzlaz.Click += new System.EventHandler(this.btnIzlaz_Click);
            // 
            // dgvPrikazStanjaNaSkladistu
            // 
            this.dgvPrikazStanjaNaSkladistu.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPrikazStanjaNaSkladistu.BackgroundColor = System.Drawing.SystemColors.ScrollBar;
            this.dgvPrikazStanjaNaSkladistu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPrikazStanjaNaSkladistu.Location = new System.Drawing.Point(81, 80);
            this.dgvPrikazStanjaNaSkladistu.Name = "dgvPrikazStanjaNaSkladistu";
            this.dgvPrikazStanjaNaSkladistu.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPrikazStanjaNaSkladistu.Size = new System.Drawing.Size(496, 208);
            this.dgvPrikazStanjaNaSkladistu.TabIndex = 87;
            // 
            // FormaStanjeNaSkladistu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(663, 363);
            this.Controls.Add(this.btnIzlaz);
            this.Controls.Add(this.dgvPrikazStanjaNaSkladistu);
            this.Name = "FormaStanjeNaSkladistu";
            this.Text = "Stanje na skladištu";
            this.Load += new System.EventHandler(this.FormaStanjeNaSkladistu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPrikazStanjaNaSkladistu)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnIzlaz;
        private System.Windows.Forms.DataGridView dgvPrikazStanjaNaSkladistu;
    }
}