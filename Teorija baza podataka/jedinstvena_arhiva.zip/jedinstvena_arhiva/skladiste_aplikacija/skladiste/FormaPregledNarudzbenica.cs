﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace skladiste
{
    public partial class FormaPregledNarudzbenica : Form
    {
        public FormaPregledNarudzbenica()
        {
            InitializeComponent();
        }

        private void btnIzlaz_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormaIzbornik formaIzbornik = new FormaIzbornik();
            formaIzbornik.Closed += (s, args) => this.Close();
            formaIzbornik.ShowDialog();
        }

        private void OsvjeziNarudzbenice()
        {
            List<Narudzbenica> listaNarudzbenica = Narudzbenica.DohvatiNarudzbenice();
            dgvNarudzbenice.DataSource = listaNarudzbenica;
        }

        private void PretraziNarudzbenice()
        {
            int pretraga = int.Parse(inputIdNarudzbenice.Text);
            inputIdNarudzbenice.Clear();
            int id = 0;

            foreach (DataGridViewRow dgvr in dgvNarudzbenice.Rows)
            {
                id = Convert.ToInt32(dgvr.Cells[0].Value);

                if (pretraga == id)
                {
                    List<Narudzbenica> listaNarudzbenica = Narudzbenica.DohvatiPretrazeneNarudzbenice(pretraga);
                    dgvNarudzbenice.DataSource = listaNarudzbenica;
                }
            }

            if (pretraga != id)
            {
                MessageBox.Show("Uneseni Id ne postoji!");
            }
        }

        private void FormaPregledNarudzbenica_Load(object sender, EventArgs e)
        {
            OsvjeziNarudzbenice();
        }

        private void actionPretrazi_Click(object sender, EventArgs e)
        {
            PretraziNarudzbenice();
        }

        private void actionObrisiNarudzbenicu_Click(object sender, EventArgs e)
        {
            if (dgvNarudzbenice.SelectedRows.Count > 0)
            {
                foreach (DataGridViewRow row in dgvNarudzbenice.SelectedRows)
                {
                    Narudzbenica odabranaNarudzbenica = row.DataBoundItem as Narudzbenica;
                    odabranaNarudzbenica.BrisanjeNarudzbenice();
                }

                MessageBox.Show("Uspješno ste obrisali narudžbenicu iz baze podataka!", "Uspješno brisanje narudžbenice!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            else
            {
                MessageBox.Show("Niste odabrali narudžbenicu za brisanje!", "Upozorenje!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            OsvjeziNarudzbenice();
        }

        private void actionAzurirajNarudzbenicu_Click(object sender, EventArgs e)
        {
            if (dgvNarudzbenice.SelectedRows.Count > 0)
            {
                Narudzbenica odabranaNarudzbenica = dgvNarudzbenice.SelectedRows[0].DataBoundItem as Narudzbenica;

                this.Hide();
                FormaAzuriranjeNarudzbenice formaAzuriranjeNarudzbenice = new FormaAzuriranjeNarudzbenice(odabranaNarudzbenica);
                formaAzuriranjeNarudzbenice.Closed += (s, args) => this.Close();
                formaAzuriranjeNarudzbenice.ShowDialog();
                OsvjeziNarudzbenice();
            }
            else
            {
                MessageBox.Show("Niste odabrali narudžbenicu za ažuriranje!", "Upozorenje!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void OsvjeziStavkeNarudzbenica()
        {
            Narudzbenica odabranaNarudzbenica = dgvNarudzbenice.CurrentRow.DataBoundItem as Narudzbenica;

            StavkaNarudzbenice sn = new StavkaNarudzbenice();

            dgvStavkeNarudzbenice.DataSource = sn.DohvatiStavkeNarudzbenice(odabranaNarudzbenica.IdNarudzbenice);
        }

        private void dgvNarudzbenice_SelectionChanged(object sender, EventArgs e)
        {
            OsvjeziStavkeNarudzbenica();
        }

        private void actionSveNarudzbenice_Click(object sender, EventArgs e)
        {
            OsvjeziNarudzbenice();
        }
    }
}
