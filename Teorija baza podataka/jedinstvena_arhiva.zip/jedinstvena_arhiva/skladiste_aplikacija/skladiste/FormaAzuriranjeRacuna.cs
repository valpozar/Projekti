﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace skladiste
{
    public partial class FormaAzuriranjeRacuna : Form
    {
        private Racun racunZaIzmjenu = null;

        public FormaAzuriranjeRacuna(Racun racun)
        {
            InitializeComponent();
            racunZaIzmjenu = racun;
            dtpDatumDostave.Enabled = false;
            dtpDatumKreiranja.Enabled = false;
            label2.Enabled = false;
            label4.Enabled = false;
        }

        private void btnIzlaz_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormaPregledRacuna formaPregledRacuna = new FormaPregledRacuna();
            formaPregledRacuna.Closed += (s, args) => this.Close();
            formaPregledRacuna.ShowDialog();
        }

        private void FormaAzuriranjeRacuna_Load(object sender, EventArgs e)
        {
            outputId.Text = racunZaIzmjenu.IdRacuna.ToString();
            dtpDatumKreiranja.Text = racunZaIzmjenu.DatumKreiranja.ToString();
            inputIznos.Text = racunZaIzmjenu.Iznos.ToString();
            dtpDatumDostave.Text = racunZaIzmjenu.DatumDostave.ToString();
            inputNacinPlacanja.Text = racunZaIzmjenu.NacinPlacanja.ToString();
            inputIdKorisnika.Text = racunZaIzmjenu.IdKorisnika.ToString();
        }

        private void btnAzuriraj_Click(object sender, EventArgs e)
        {
            string datumKreiranja = dtpDatumKreiranja.Value.ToString("yyyy-MM-dd");
            float iznos = float.Parse(inputIznos.Text);
            string datumDostave = dtpDatumDostave.Value.ToString("yyyy-MM-dd");
            string nacinPlacanja = inputNacinPlacanja.Text;
            int idKorisnika = int.Parse(inputIdKorisnika.Text);

            if (String.IsNullOrWhiteSpace(dtpDatumKreiranja.Text) || String.IsNullOrWhiteSpace(inputIznos.Text) || String.IsNullOrWhiteSpace(dtpDatumDostave.Text) || String.IsNullOrWhiteSpace(inputNacinPlacanja.Text) || String.IsNullOrWhiteSpace(inputIdKorisnika.Text))
            {
                MessageBox.Show("Unesite sve podatke za uspješno ažuriranje računa!", "Upozorenje!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                Racun racun = new Racun();
                racun.AzuriranjeRacuna(racunZaIzmjenu.IdRacuna, datumKreiranja, iznos, datumDostave, nacinPlacanja, idKorisnika);

                MessageBox.Show("Uspješno ste ažurirali račun u bazi podataka!", "Uspješno ažuriranje računa!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.Hide();
                FormaPregledRacuna formaPregledRacuna = new FormaPregledRacuna();
                formaPregledRacuna.Closed += (s, args) => this.Close();
                formaPregledRacuna.ShowDialog();
            }
        }
    }
}
