﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;

namespace skladiste
{
    public class Racun
    {
        public int IdRacuna { get; set; }
        public DateTime DatumKreiranja { get; set; }
        public DateTime DatumDostave { get; set; }
        public float Iznos { get; set; }
        public string NacinPlacanja { get; set; }
        public int IdKorisnika { get; set; }

        public Racun()
        {

        }

        public Racun(DbDataReader podaci)
        {
            if (podaci != null)
            {

                IdRacuna = int.Parse(podaci["id_racuna"].ToString());
                DatumKreiranja = DateTime.Parse(podaci["datum_kreiranja"].ToString());
                DatumDostave = DateTime.Parse(podaci["datum_dostave"].ToString());
                Iznos = float.Parse(podaci["iznos"].ToString());
                NacinPlacanja = podaci["nacin_placanja"].ToString();
                IdKorisnika = int.Parse(podaci["id_korisnika"].ToString());
            }
        }

        public static List<Racun> DohvatiRacune()
        {
            List<Racun> lista = new List<Racun>();
            string sqlUpit = "SELECT * FROM racun";
            DbDataReader dr = DB.Instance.DohvatiDataReader(sqlUpit);
            while (dr.Read())
            {

                Racun racun = new Racun(dr);
                lista.Add(racun);
            }
            dr.Close();
            return lista;
        }

        public static List<Racun> DohvatiRacunePrijavljenogKorisnika(int id)
        {
            List<Racun> lista = new List<Racun>();
            string sqlUpit = "SELECT * FROM racun WHERE id_korisnika = " + id;
            DbDataReader dr = DB.Instance.DohvatiDataReader(sqlUpit);
            while (dr.Read())
            {

                Racun racun = new Racun(dr);
                lista.Add(racun);
            }
            dr.Close();
            return lista;
        }

        public static List<Racun> DohvatiPretrazeneRacune(int pretraga)
        {
            List<Racun> lista = new List<Racun>();
            string sqlUpit = "SELECT * FROM racun WHERE id_racuna = " + pretraga;
            DbDataReader dr = DB.Instance.DohvatiDataReader(sqlUpit);
            while (dr.Read())
            {

                Racun racun = new Racun(dr);
                lista.Add(racun);
            }
            dr.Close();
            return lista;
        }

        public void BrisanjeRacuna()
        {
            string sqlUpit = "DELETE FROM racun WHERE  id_racuna = " + this.IdRacuna;
            DB.Instance.IzvrsiUpit(sqlUpit);
        }

        public void AzuriranjeRacuna(int id, string datumKreiranja, float iznos, string datumDostave, string nacinPlacanja, int idKorisnika)
        {
            string sqlUpit = "UPDATE racun SET datum_kreiranja = default, iznos = '" + iznos + "' , datum_dostave = default , nacin_placanja = '" + nacinPlacanja + "' , id_korisnika = '" + idKorisnika + "'WHERE id_racuna = " + id;
            DB.Instance.IzvrsiUpit(sqlUpit);
        }

        public void DodavanjeRacuna(string datumKreiranja, string datumDostave, float iznos, string nacinPlacanja, int idKorisnika)
        {
            string sqlUpit = "INSERT INTO racun (datum_kreiranja, iznos, datum_dostave, nacin_placanja, id_korisnika) VALUES ('" + datumKreiranja + "','" + iznos + "','" + datumDostave + "','" + nacinPlacanja + "','" + idKorisnika + "')";
            DB.Instance.IzvrsiUpit(sqlUpit);
        }
    }
}
