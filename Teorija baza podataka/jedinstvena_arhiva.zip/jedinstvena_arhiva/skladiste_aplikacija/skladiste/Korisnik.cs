﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;

namespace skladiste
{
    public class Korisnik
    {
        public int IDKorisnika { get; set; }
        public string Ime { get; set; }
        public string Prezime { get; set; }
        public string Email { get; set; }
        public string Lozinka { get; set; }
        public string Adresa { get; set; }
        public string Kontakt { get; set; }
        public int IDVrsteKorisnika { get; set; }

        public Korisnik(string ime, string prezime, string email, string lozinka, string adresa, string kontakt)
        {
            Ime = ime;
            Prezime = prezime;
            Email = email;
            Lozinka = lozinka;
            Adresa = adresa;
            Kontakt = kontakt;
        }

        public Korisnik(DbDataReader dr)
        {
            if (dr != null)
            {
                IDKorisnika = int.Parse(dr["id_korisnika"].ToString());
                Ime = dr["ime"].ToString();
                Prezime = dr["prezime"].ToString();
                Email = dr["email"].ToString();
                Lozinka = dr["lozinka"].ToString();
                Adresa = dr["adresa"].ToString();
                Kontakt = dr["kontakt"].ToString();
                IDVrsteKorisnika = int.Parse(dr["id_vrste_korisnika"].ToString());
            }
        }

        public static int ProvjeraEmaila(string email)
        {
            string sqlUpit = "SELECT COUNT(*) FROM korisnik WHERE email = '" + email + "'";

            return Convert.ToInt32(DB.Instance.DohvatiVrijednost(sqlUpit));
        }

        public static Korisnik DohvacanjeKorisnika(string email)
        {
            Korisnik korisnik = null;
            string sqlUpit = "SELECT * FROM korisnik WHERE email = '" + email + "'";
            DbDataReader dr = DB.Instance.DohvatiDataReader(sqlUpit);
            while (dr.Read())
            {
                korisnik = new Korisnik(dr);
            }
            dr.Close();
            return korisnik;
        }

        public int UnosNovogKupcaUBazu()
        {
            string sqlUpit = "INSERT INTO korisnik (id_korisnika, ime, prezime, email, lozinka, adresa, kontakt, id_vrste_korisnika) VALUES (default, '" + Ime + "','" + Prezime + "','" + Email + "','" + Lozinka + "','" + Adresa + "','" + Kontakt + "', 3)";
            return DB.Instance.IzvrsiUpit(sqlUpit);
        }

        public static List<Korisnik> DohvacanjeZaposlenika(string kljucnaRijec)
        {
            List<Korisnik> listaZaposlenika = new List<Korisnik>();
            string sqlUpit = "SELECT * FROM korisnik WHERE email LIKE '%" + kljucnaRijec + "%' AND id_vrste_korisnika = 2";
            DbDataReader dr = DB.Instance.DohvatiDataReader(sqlUpit);

            while (dr.Read())
            {
                Korisnik zaposlenik = new Korisnik(dr);
                listaZaposlenika.Add(zaposlenik);
            }
            dr.Close();
            return listaZaposlenika;
        }

        public int BrisanjeZaposlenika()
        {
            string sqlDelete = "DELETE FROM korisnik WHERE id_korisnika = " + IDKorisnika;
            return DB.Instance.IzvrsiUpit(sqlDelete);
        }

        public int SpremanjeZaposlenika()
        {
            string sqlUpit = "";
            if (IDKorisnika == 0)
            {
                sqlUpit = "INSERT INTO korisnik (id_korisnika, ime, prezime, email, lozinka, adresa, kontakt, id_vrste_korisnika) VALUES (default, '" + Ime + "','" + Prezime + "','" + Email + "','" + Lozinka + "','" + Adresa + "','" + Kontakt + "', 2)";
            }
            else
            {
                sqlUpit = "UPDATE korisnik SET ime = '" + Ime + "', prezime = '" + Prezime + "', email = '" + Email + "', lozinka = '" + Lozinka + "', adresa = '" + Adresa + "', kontakt = '" + Kontakt + "' WHERE id_korisnika = " + IDKorisnika;
            }
            return DB.Instance.IzvrsiUpit(sqlUpit);
        }
    }
}
