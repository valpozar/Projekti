﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Common;

namespace skladiste
{
    public class StavkaNarudzbenice
    {
        public ArtiklUpravljanje NazivArtikla { get; set; }
        public string Naziv;
        public float Cijena { get; set; }
        public int Kolicina { get; set; }
        public Narudzbenica Nar;

        public StavkaNarudzbenice()
        {

        }

        public StavkaNarudzbenice(DbDataReader podaci)
        {
            if (podaci != null)
            {
                Kolicina = int.Parse(podaci["kolicina"].ToString());
                Nar = new Narudzbenica();
                Nar.IdNarudzbenice = int.Parse(podaci["id_narudzbenice"].ToString());
                NazivArtikla = new ArtiklUpravljanje();
                NazivArtikla.IdArtikla = int.Parse(podaci["id_artikla"].ToString());
                NazivArtikla.Naziv = podaci["naziv"].ToString();
                Cijena = float.Parse(podaci["cijena"].ToString());
            }
        }

        public List<StavkaNarudzbenice> DohvatiStavkeNarudzbenice(int id)
        {
            List<StavkaNarudzbenice> lista = new List<StavkaNarudzbenice>();
            string sqlUpit = "SELECT n.id_narudzbenice, a.id_artikla, s.kolicina, a.naziv, a.cijena FROM narudzbenica n JOIN stavke_narudzbenice s ON n.id_narudzbenice=s.id_narudzbenice JOIN artikl a ON s.id_artikla=a.id_artikla WHERE s.id_narudzbenice = " + id;
            DbDataReader dr = DB.Instance.DohvatiDataReader(sqlUpit);
            while (dr.Read())
            {

                StavkaNarudzbenice stavkaNarudzbenice = new StavkaNarudzbenice(dr);
                lista.Add(stavkaNarudzbenice);
            }
            dr.Close();
            return lista;
        }

        public override string ToString()
        {
            return Kolicina.ToString();
        }
    }
}
