﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;

namespace skladiste
{
    public class ArtiklUpravljanje
    {
        public int IdArtikla { get; set; }
        public string Naziv { get; set; }
        public float Cijena { get; set; }
        public string JedinicaMjere { get; set; }

        public ArtiklUpravljanje(string naziv, float cijena, string jedinica_mjere)
        {
            Naziv = naziv;
            Cijena = cijena;
            JedinicaMjere = jedinica_mjere;
        }

        public ArtiklUpravljanje(string naziv)
        {
            Naziv = naziv;
        }

        public ArtiklUpravljanje()
        {

        }

        public ArtiklUpravljanje(DbDataReader podaci)
        {

            if (podaci != null)
            {
                IdArtikla = int.Parse(podaci["id_artikla"].ToString());
                Naziv = podaci["naziv"].ToString();
                Cijena = float.Parse(podaci["cijena"].ToString());
                JedinicaMjere = podaci["jedinica_mjere"].ToString();
            }
        }

        public static List<ArtiklUpravljanje> DohvacanjeArtikala()
        {
            List<ArtiklUpravljanje> lista = new List<ArtiklUpravljanje>();
            string sqlUpit = "SELECT id_artikla, naziv, cijena, jedinica_mjere FROM artikl";
            DbDataReader dr = DB.Instance.DohvatiDataReader(sqlUpit);
            while (dr.Read())
            {
                ArtiklUpravljanje artikl = new ArtiklUpravljanje(dr);
                lista.Add(artikl);
            }
            dr.Close();
            return lista;
        }

        public static List<ArtiklUpravljanje> DohvacanjePretrazenihArtikala(string pretraga)
        {
            List<ArtiklUpravljanje> lista = new List<ArtiklUpravljanje>();
            string sqlUpit = "SELECT id_artikla, naziv, cijena, jedinica_mjere FROM artikl WHERE naziv LIKE '%" + pretraga + "%'";
            DbDataReader dr = DB.Instance.DohvatiDataReader(sqlUpit);
            while (dr.Read())
            {
                ArtiklUpravljanje artikl = new ArtiklUpravljanje(dr);
                lista.Add(artikl);
            }
            dr.Close();
            return lista;
        }

        public static int ProvjeraNaziva(string naziv)
        {
            string sqlUpit = "SELECT COUNT(*) FROM artikl WHERE naziv = '" + naziv + "'";

            return Convert.ToInt32(DB.Instance.DohvatiVrijednost(sqlUpit));
        }

        public int SpremanjeArtikla()
        {
            string sqlUpit = "";
            if (IdArtikla == 0)
            {
                sqlUpit = "INSERT INTO artikl (id_artikla, naziv, cijena, jedinica_mjere) VALUES (default, '" + Naziv + "','" + Cijena + "','" + JedinicaMjere + "')";
            }
            else
            {
                sqlUpit = "UPDATE artikl SET naziv = '" + Naziv + "', cijena = '" + Cijena + "', jedinica_mjere = '" + JedinicaMjere + "' WHERE id_artikla = " + IdArtikla;
            }
            return DB.Instance.IzvrsiUpit(sqlUpit);
        }

        public int BrisanjeArtikla()
        {
            string sqlDelete = "DELETE FROM artikl WHERE id_artikla = " + IdArtikla;
            return DB.Instance.IzvrsiUpit(sqlDelete);
        }

        public override string ToString()
        {
            return Naziv;
        }
    }
}
