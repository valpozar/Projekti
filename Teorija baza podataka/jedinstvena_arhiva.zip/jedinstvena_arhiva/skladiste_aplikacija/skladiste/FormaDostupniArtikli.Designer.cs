﻿namespace skladiste
{
    partial class FormaDostupniArtikli
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.inputPretraga = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnIzlaz = new System.Windows.Forms.Button();
            this.dgvPrikazArtikala = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPrikazArtikala)).BeginInit();
            this.SuspendLayout();
            // 
            // inputPretraga
            // 
            this.inputPretraga.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.inputPretraga.Location = new System.Drawing.Point(549, 15);
            this.inputPretraga.Name = "inputPretraga";
            this.inputPretraga.Size = new System.Drawing.Size(100, 20);
            this.inputPretraga.TabIndex = 31;
            this.inputPretraga.TextChanged += new System.EventHandler(this.inputPretraga_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(425, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 13);
            this.label1.TabIndex = 30;
            this.label1.Text = "Pretraga po nazivu:";
            // 
            // btnIzlaz
            // 
            this.btnIzlaz.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnIzlaz.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIzlaz.Location = new System.Drawing.Point(10, 10);
            this.btnIzlaz.Name = "btnIzlaz";
            this.btnIzlaz.Size = new System.Drawing.Size(39, 25);
            this.btnIzlaz.TabIndex = 29;
            this.btnIzlaz.Text = "<--";
            this.btnIzlaz.UseVisualStyleBackColor = false;
            this.btnIzlaz.Click += new System.EventHandler(this.btnIzlaz_Click);
            // 
            // dgvPrikazArtikala
            // 
            this.dgvPrikazArtikala.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPrikazArtikala.BackgroundColor = System.Drawing.SystemColors.ScrollBar;
            this.dgvPrikazArtikala.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPrikazArtikala.Location = new System.Drawing.Point(83, 97);
            this.dgvPrikazArtikala.Name = "dgvPrikazArtikala";
            this.dgvPrikazArtikala.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPrikazArtikala.Size = new System.Drawing.Size(496, 208);
            this.dgvPrikazArtikala.TabIndex = 28;
            // 
            // FormaDostupniArtikli
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(663, 363);
            this.Controls.Add(this.inputPretraga);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnIzlaz);
            this.Controls.Add(this.dgvPrikazArtikala);
            this.Name = "FormaDostupniArtikli";
            this.Text = "Dostupni artikli";
            this.Load += new System.EventHandler(this.FormaDostupniArtikli_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPrikazArtikala)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox inputPretraga;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnIzlaz;
        private System.Windows.Forms.DataGridView dgvPrikazArtikala;
    }
}