﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace skladiste
{
    public partial class FormaUnosArtikala : Form
    {
        private ArtiklUpravljanje artikl = null;
        private string naziv = "";
        private float cijena = 0;
        private string jedinica_mjere = "";

        public FormaUnosArtikala()
        {
            InitializeComponent();
        }

        private void btnUnesi_Click(object sender, EventArgs e)
        {
            naziv = inputNaziv.Text;
            cijena = float.Parse(inputCijena.Text);
            jedinica_mjere = inputJedinicaMjere.Text;

            int postojiNaziv = 0;

            if (String.IsNullOrWhiteSpace(naziv) || String.IsNullOrWhiteSpace(jedinica_mjere))
            {
                MessageBox.Show("Morate unijeti sve podatke!", "Upozorenje!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                postojiNaziv = ArtiklUpravljanje.ProvjeraNaziva(naziv);
                if (postojiNaziv == 1)
                {
                    MessageBox.Show("Uneseni naziv već postoji!", "Upozorenje!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    artikl = new ArtiklUpravljanje(naziv, cijena,jedinica_mjere);
                    artikl.SpremanjeArtikla();

                    MessageBox.Show("Uspješan unos artikla!", "Uspješno dodavanje artikla!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    this.Hide();
                    FormaArtikli formaArtikli = new FormaArtikli();
                    formaArtikli.Closed += (s, args) => this.Close();
                    formaArtikli.ShowDialog();
                }
            }
        }

        private void btnIzlaz_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormaArtikli formaArtikli = new FormaArtikli();
            formaArtikli.Closed += (s, args) => this.Close();
            formaArtikli.ShowDialog();
        }
    }
}
