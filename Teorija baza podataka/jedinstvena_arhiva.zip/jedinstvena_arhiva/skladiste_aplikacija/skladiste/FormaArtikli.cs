﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace skladiste
{
    public partial class FormaArtikli : Form
    {
        public FormaArtikli()
        {
            InitializeComponent();
        }

        private void btnIzlaz_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormaIzbornik formaIzbornik = new FormaIzbornik();
            formaIzbornik.FormClosed += (s, args) => this.Close();
            formaIzbornik.ShowDialog();
        }

        private void OsvjeziArtikl()
        {
            List<ArtiklUpravljanje> listaArtikalaUpravljanje = ArtiklUpravljanje.DohvacanjePretrazenihArtikala(inputPretraga.Text);
            dgvPrikazArtikala.DataSource = listaArtikalaUpravljanje;
        }

        private void FormaArtikli_Load(object sender, EventArgs e)
        {
            OsvjeziArtikl();
        }

        private void inputPretraga_TextChanged(object sender, EventArgs e)
        {
            OsvjeziArtikl();
        }

        private void btnDodajArtikl_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormaUnosArtikala formaUnosArtikala = new FormaUnosArtikala();
            formaUnosArtikala.Closed += (s, args) => this.Close();
            formaUnosArtikala.ShowDialog();
            OsvjeziArtikl();
        }

        private void btnAzurirajPodatkeArtikla_Click(object sender, EventArgs e)
        {
            if (dgvPrikazArtikala.SelectedRows.Count > 0)
            {
                ArtiklUpravljanje odabraniArtikl = dgvPrikazArtikala.SelectedRows[0].DataBoundItem as ArtiklUpravljanje;

                this.Hide();
                FormaAzuriranjeArtikala formaAzuriranjeArtikla = new FormaAzuriranjeArtikala(odabraniArtikl);
                formaAzuriranjeArtikla.Closed += (s, args) => this.Close();
                formaAzuriranjeArtikla.ShowDialog();
                OsvjeziArtikl();
            }
            else
            {
                MessageBox.Show("Morate odabrati artikl!", "Upozorenje!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnIzbrisiArtikl_Click(object sender, EventArgs e)
        {
            if (dgvPrikazArtikala.SelectedRows.Count > 0)
            {
                foreach (DataGridViewRow row in dgvPrikazArtikala.SelectedRows)
                {
                    ArtiklUpravljanje artikl = row.DataBoundItem as ArtiklUpravljanje;
                    artikl.BrisanjeArtikla();
                }

                MessageBox.Show("Uspješno brisanje artikla!", "Uspješno brisanje artikla!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Morate odabrati artikl!", "Upozorenje!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            OsvjeziArtikl();
        }

        private void dgvPrikazArtikala_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvPrikazArtikala.CurrentRow != null)
            {
                DataGridViewRow selektiraniRedak = dgvPrikazArtikala.CurrentRow;
                DataGridViewCell selektiraniId = selektiraniRedak.Cells[0];
                int idArtikla = int.Parse(selektiraniId.Value.ToString());
                lblKolicina.Text = "Količina na skladištu (odabranog artikla): " + StavkaPrimke.DohvatiKolicinuSaSkladista(idArtikla);
            }
        }
    }
}
