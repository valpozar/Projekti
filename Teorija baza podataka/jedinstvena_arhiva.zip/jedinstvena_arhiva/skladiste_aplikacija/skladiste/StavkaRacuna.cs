﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Common;

namespace skladiste
{
   public class StavkaRacuna
    {
        public ArtiklUpravljanje NazivArtikla { get; set; }
        public float Cijena { get; set; }
        public int Kolicina { get; set; }
        public Racun Rac;
        public int IdRacuna;
        public int IdArtikla;

        public StavkaRacuna()
        {

        }

        public StavkaRacuna(int kolicina, int idracuna, int idartikla)
        {
            Kolicina = kolicina;
            IdRacuna = idracuna;
            IdArtikla = idartikla;
        }

        public StavkaRacuna(DbDataReader podaci)
        {
            if (podaci != null)
            {
                Kolicina = int.Parse(podaci["kolicina"].ToString());
                Rac = new Racun();
                Rac.IdRacuna = int.Parse(podaci["id_racuna"].ToString());
                NazivArtikla = new ArtiklUpravljanje();
                NazivArtikla.IdArtikla = int.Parse(podaci["id_artikla"].ToString());
                NazivArtikla.Naziv = podaci["naziv"].ToString();
                Cijena = float.Parse(podaci["cijena"].ToString());
            }
        }

        public List<StavkaRacuna> DohvatiStavkeRacuna(int id)
        {
            List<StavkaRacuna> lista = new List<StavkaRacuna>();
            string sqlUpit = "SELECT r.id_racuna, a.id_artikla, s.kolicina, a.naziv, a.cijena FROM racun r JOIN stavke_racuna s ON r.id_racuna=s.id_racuna JOIN artikl a ON s.id_artikla=a.id_artikla WHERE s.id_racuna = " + id;
            DbDataReader dr = DB.Instance.DohvatiDataReader(sqlUpit);
            while (dr.Read())
            {

                StavkaRacuna stavkeRacuna = new StavkaRacuna(dr);
                lista.Add(stavkeRacuna);
            }
            dr.Close();
            return lista;
        }

        public override string ToString()
        {
            return Kolicina.ToString();
        }

        public void DodajStavkuRacuna()
        {
            string sqlUpit = "INSERT INTO stavke_racuna (kolicina, id_racuna, id_artikla) VALUES ('" + this.Kolicina + "','" + this.IdRacuna + "','" + this.IdArtikla + "')";
            DB.Instance.IzvrsiUpit(sqlUpit);
        }
    }
}
