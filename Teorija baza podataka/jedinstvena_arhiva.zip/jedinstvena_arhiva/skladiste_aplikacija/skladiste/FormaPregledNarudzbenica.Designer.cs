﻿namespace skladiste
{
    partial class FormaPregledNarudzbenica
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnIzlaz = new System.Windows.Forms.Button();
            this.actionSveNarudzbenice = new System.Windows.Forms.Button();
            this.actionAzurirajNarudzbenicu = new System.Windows.Forms.Button();
            this.actionObrisiNarudzbenicu = new System.Windows.Forms.Button();
            this.dgvStavkeNarudzbenice = new System.Windows.Forms.DataGridView();
            this.actionPretrazi = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.inputIdNarudzbenice = new System.Windows.Forms.TextBox();
            this.dgvNarudzbenice = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStavkeNarudzbenice)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNarudzbenice)).BeginInit();
            this.SuspendLayout();
            // 
            // btnIzlaz
            // 
            this.btnIzlaz.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnIzlaz.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIzlaz.Location = new System.Drawing.Point(13, 10);
            this.btnIzlaz.Name = "btnIzlaz";
            this.btnIzlaz.Size = new System.Drawing.Size(39, 25);
            this.btnIzlaz.TabIndex = 80;
            this.btnIzlaz.Text = "<--";
            this.btnIzlaz.UseVisualStyleBackColor = false;
            this.btnIzlaz.Click += new System.EventHandler(this.btnIzlaz_Click);
            // 
            // actionSveNarudzbenice
            // 
            this.actionSveNarudzbenice.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.actionSveNarudzbenice.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.actionSveNarudzbenice.Location = new System.Drawing.Point(572, 22);
            this.actionSveNarudzbenice.Name = "actionSveNarudzbenice";
            this.actionSveNarudzbenice.Size = new System.Drawing.Size(123, 23);
            this.actionSveNarudzbenice.TabIndex = 79;
            this.actionSveNarudzbenice.Text = "Sve narudžbenice";
            this.actionSveNarudzbenice.UseVisualStyleBackColor = false;
            this.actionSveNarudzbenice.Click += new System.EventHandler(this.actionSveNarudzbenice_Click);
            // 
            // actionAzurirajNarudzbenicu
            // 
            this.actionAzurirajNarudzbenicu.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.actionAzurirajNarudzbenicu.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.actionAzurirajNarudzbenicu.Location = new System.Drawing.Point(734, 108);
            this.actionAzurirajNarudzbenicu.Name = "actionAzurirajNarudzbenicu";
            this.actionAzurirajNarudzbenicu.Size = new System.Drawing.Size(99, 43);
            this.actionAzurirajNarudzbenicu.TabIndex = 78;
            this.actionAzurirajNarudzbenicu.Text = "Ažuriraj narudžbenicu";
            this.actionAzurirajNarudzbenicu.UseVisualStyleBackColor = false;
            this.actionAzurirajNarudzbenicu.Click += new System.EventHandler(this.actionAzurirajNarudzbenicu_Click);
            // 
            // actionObrisiNarudzbenicu
            // 
            this.actionObrisiNarudzbenicu.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.actionObrisiNarudzbenicu.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.actionObrisiNarudzbenicu.Location = new System.Drawing.Point(734, 60);
            this.actionObrisiNarudzbenicu.Name = "actionObrisiNarudzbenicu";
            this.actionObrisiNarudzbenicu.Size = new System.Drawing.Size(99, 42);
            this.actionObrisiNarudzbenicu.TabIndex = 77;
            this.actionObrisiNarudzbenicu.Text = "Obriši narudžbenicu";
            this.actionObrisiNarudzbenicu.UseVisualStyleBackColor = false;
            this.actionObrisiNarudzbenicu.Click += new System.EventHandler(this.actionObrisiNarudzbenicu_Click);
            // 
            // dgvStavkeNarudzbenice
            // 
            this.dgvStavkeNarudzbenice.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvStavkeNarudzbenice.BackgroundColor = System.Drawing.SystemColors.ScrollBar;
            this.dgvStavkeNarudzbenice.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvStavkeNarudzbenice.DefaultCellStyle = dataGridViewCellStyle5;
            this.dgvStavkeNarudzbenice.Location = new System.Drawing.Point(22, 280);
            this.dgvStavkeNarudzbenice.Name = "dgvStavkeNarudzbenice";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvStavkeNarudzbenice.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dgvStavkeNarudzbenice.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvStavkeNarudzbenice.Size = new System.Drawing.Size(673, 198);
            this.dgvStavkeNarudzbenice.TabIndex = 76;
            // 
            // actionPretrazi
            // 
            this.actionPretrazi.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.actionPretrazi.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.actionPretrazi.Location = new System.Drawing.Point(475, 22);
            this.actionPretrazi.Name = "actionPretrazi";
            this.actionPretrazi.Size = new System.Drawing.Size(75, 23);
            this.actionPretrazi.TabIndex = 75;
            this.actionPretrazi.Text = "Pretraži";
            this.actionPretrazi.UseVisualStyleBackColor = false;
            this.actionPretrazi.Click += new System.EventHandler(this.actionPretrazi_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label1.Location = new System.Drawing.Point(288, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 13);
            this.label1.TabIndex = 74;
            this.label1.Text = "ID narudžbenice:";
            // 
            // inputIdNarudzbenice
            // 
            this.inputIdNarudzbenice.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.inputIdNarudzbenice.Location = new System.Drawing.Point(382, 24);
            this.inputIdNarudzbenice.Name = "inputIdNarudzbenice";
            this.inputIdNarudzbenice.Size = new System.Drawing.Size(60, 20);
            this.inputIdNarudzbenice.TabIndex = 73;
            // 
            // dgvNarudzbenice
            // 
            this.dgvNarudzbenice.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvNarudzbenice.BackgroundColor = System.Drawing.SystemColors.ScrollBar;
            this.dgvNarudzbenice.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvNarudzbenice.DefaultCellStyle = dataGridViewCellStyle7;
            this.dgvNarudzbenice.Location = new System.Drawing.Point(22, 60);
            this.dgvNarudzbenice.Name = "dgvNarudzbenice";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvNarudzbenice.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.dgvNarudzbenice.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvNarudzbenice.Size = new System.Drawing.Size(673, 198);
            this.dgvNarudzbenice.TabIndex = 72;
            this.dgvNarudzbenice.SelectionChanged += new System.EventHandler(this.dgvNarudzbenice_SelectionChanged);
            // 
            // FormaPregledNarudzbenica
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(862, 521);
            this.Controls.Add(this.btnIzlaz);
            this.Controls.Add(this.actionSveNarudzbenice);
            this.Controls.Add(this.actionAzurirajNarudzbenicu);
            this.Controls.Add(this.actionObrisiNarudzbenicu);
            this.Controls.Add(this.dgvStavkeNarudzbenice);
            this.Controls.Add(this.actionPretrazi);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.inputIdNarudzbenice);
            this.Controls.Add(this.dgvNarudzbenice);
            this.Name = "FormaPregledNarudzbenica";
            this.Text = "Pregled narudžbenica";
            this.Load += new System.EventHandler(this.FormaPregledNarudzbenica_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvStavkeNarudzbenice)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNarudzbenice)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnIzlaz;
        private System.Windows.Forms.Button actionSveNarudzbenice;
        private System.Windows.Forms.Button actionAzurirajNarudzbenicu;
        private System.Windows.Forms.Button actionObrisiNarudzbenicu;
        private System.Windows.Forms.DataGridView dgvStavkeNarudzbenice;
        private System.Windows.Forms.Button actionPretrazi;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox inputIdNarudzbenice;
        private System.Windows.Forms.DataGridView dgvNarudzbenice;
    }
}