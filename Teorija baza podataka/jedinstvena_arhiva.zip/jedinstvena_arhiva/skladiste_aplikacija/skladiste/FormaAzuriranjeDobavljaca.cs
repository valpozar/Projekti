﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace skladiste
{
    public partial class FormaAzuriranjeDobavljaca : Form
    {
        private Dobavljac azuriranjeDobavljaca = null;

        public FormaAzuriranjeDobavljaca(Dobavljac dobavljac)
        {
            InitializeComponent();
            azuriranjeDobavljaca = dobavljac;
        }

        private void btnIzlaz_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormaDobavljaci formaDobavljaci = new FormaDobavljaci();
            formaDobavljaci.Closed += (s, args) => this.Close();
            formaDobavljaci.ShowDialog();
        }

        private void btnAzuriraj_Click(object sender, EventArgs e)
        {
            azuriranjeDobavljaca.Naziv = inputNaziv.Text;
            azuriranjeDobavljaca.Adresa = inputAdresa.Text;
            azuriranjeDobavljaca.Kontakt = inputKontakt.Text;

            if (String.IsNullOrWhiteSpace(inputNaziv.Text) || String.IsNullOrWhiteSpace(inputAdresa.Text) || String.IsNullOrWhiteSpace(inputKontakt.Text))
            {
                MessageBox.Show("Morate unijeti sve podatke!", "Upozorenje!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                azuriranjeDobavljaca.SpremanjeDobavljaca();

                MessageBox.Show("Uspješno ažuriranje!", "Uspješno ažuriranje dobavljača!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.Hide();
                FormaDobavljaci formaDobavljaci = new FormaDobavljaci();
                formaDobavljaci.Closed += (s, args) => this.Close();
                formaDobavljaci.ShowDialog();
            }
        }

        private void FormaAzuriranjeDobavljaca_Load(object sender, EventArgs e)
        {
            inputNaziv.Text = azuriranjeDobavljaca.Naziv;
            inputAdresa.Text = azuriranjeDobavljaca.Adresa;
            inputKontakt.Text = azuriranjeDobavljaca.Kontakt;
        }
    }
}
