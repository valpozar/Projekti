﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace skladiste
{
    public partial class FormaPregledPrimki : Form
    {
        public FormaPregledPrimki()
        {
            InitializeComponent();
        }

        private void btnIzlaz_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormaIzbornik formaIzbornik = new FormaIzbornik();
            formaIzbornik.Closed += (s, args) => this.Close();
            formaIzbornik.ShowDialog();
        }

        private void OsvjeziPrimke()
        {
            List<Primka> listaPrimki = Primka.DohvatiPrimke();
            dgvPrimke.DataSource = listaPrimki;
        }

        private void PretraziPrimke()
        {
            int pretraga = int.Parse(inputIdPrimke.Text);
            inputIdPrimke.Clear();
            int id = 0;

            foreach (DataGridViewRow dgvr in dgvPrimke.Rows)
            {
                id = Convert.ToInt32(dgvr.Cells[0].Value);

                if (pretraga == id)
                {
                    List<Primka> listaPrimki = Primka.DohvatiPretrazenePrimke(pretraga);
                    dgvPrimke.DataSource = listaPrimki;
                }
            }

            if (pretraga != id)
            {
                MessageBox.Show("Uneseni Id ne postoji!");
            }
        }

        private void FormaPregledPrimki_Load(object sender, EventArgs e)
        {
            OsvjeziPrimke();
        }

        private void actionPretrazi_Click(object sender, EventArgs e)
        {
            PretraziPrimke();
        }

        private void actionObrisiPrimku_Click(object sender, EventArgs e)
        {
            if (dgvPrimke.SelectedRows.Count > 0)
            {
                foreach (DataGridViewRow row in dgvPrimke.SelectedRows)
                {
                    Primka odabranaPrimka = row.DataBoundItem as Primka;
                    odabranaPrimka.BrisanjePrimke();
                }

                MessageBox.Show("Uspješno ste obrisali primku iz baze podataka!", "Uspješno brisanje primke!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            else
            {
                MessageBox.Show("Niste odabrali primku za brisanje!", "Upozorenje!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            OsvjeziPrimke();
        }

        private void actionAzurirajPrimku_Click(object sender, EventArgs e)
        {
            if (dgvPrimke.SelectedRows.Count > 0)
            {
                Primka odabranaPrimka = dgvPrimke.SelectedRows[0].DataBoundItem as Primka;

                this.Hide();
                FormaAzuriranjePrimke formaAzuriranjePrimke = new FormaAzuriranjePrimke(odabranaPrimka);
                formaAzuriranjePrimke.Closed += (s, args) => this.Close();
                formaAzuriranjePrimke.ShowDialog();
                OsvjeziPrimke();
            }
            else
            {
                MessageBox.Show("Niste odabrali primku za ažuriranje!", "Upozorenje!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void OsvjeziStavkePrimki()
        {
            Primka odabranaPrimka = dgvPrimke.CurrentRow.DataBoundItem as Primka;

            StavkaPrimke sp = new StavkaPrimke();

            dgvStavkaPrimke.DataSource = sp.DohvatiStavkePrimke(odabranaPrimka.IdPrimke);

        }

        private void dgvPrimke_SelectionChanged(object sender, EventArgs e)
        {
            OsvjeziStavkePrimki();
        }

        private void actionSvePrimke_Click(object sender, EventArgs e)
        {
            OsvjeziPrimke();
        }
    }
}
