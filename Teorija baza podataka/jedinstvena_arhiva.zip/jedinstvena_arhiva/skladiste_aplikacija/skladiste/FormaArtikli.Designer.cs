﻿namespace skladiste
{
    partial class FormaArtikli
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnIzbrisiArtikl = new System.Windows.Forms.Button();
            this.btnAzurirajPodatkeArtikla = new System.Windows.Forms.Button();
            this.btnDodajArtikl = new System.Windows.Forms.Button();
            this.btnIzlaz = new System.Windows.Forms.Button();
            this.inputPretraga = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvPrikazArtikala = new System.Windows.Forms.DataGridView();
            this.lblKolicina = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPrikazArtikala)).BeginInit();
            this.SuspendLayout();
            // 
            // btnIzbrisiArtikl
            // 
            this.btnIzbrisiArtikl.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnIzbrisiArtikl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnIzbrisiArtikl.Location = new System.Drawing.Point(429, 295);
            this.btnIzbrisiArtikl.Name = "btnIzbrisiArtikl";
            this.btnIzbrisiArtikl.Size = new System.Drawing.Size(110, 53);
            this.btnIzbrisiArtikl.TabIndex = 43;
            this.btnIzbrisiArtikl.Text = "IZBRIŠI ARTIKL IZ BAZE";
            this.btnIzbrisiArtikl.UseVisualStyleBackColor = false;
            this.btnIzbrisiArtikl.Click += new System.EventHandler(this.btnIzbrisiArtikl_Click);
            // 
            // btnAzurirajPodatkeArtikla
            // 
            this.btnAzurirajPodatkeArtikla.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnAzurirajPodatkeArtikla.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnAzurirajPodatkeArtikla.Location = new System.Drawing.Point(275, 295);
            this.btnAzurirajPodatkeArtikla.Name = "btnAzurirajPodatkeArtikla";
            this.btnAzurirajPodatkeArtikla.Size = new System.Drawing.Size(110, 53);
            this.btnAzurirajPodatkeArtikla.TabIndex = 42;
            this.btnAzurirajPodatkeArtikla.Text = "AŽURIRAJ PODATKE ARTIKLA";
            this.btnAzurirajPodatkeArtikla.UseVisualStyleBackColor = false;
            this.btnAzurirajPodatkeArtikla.Click += new System.EventHandler(this.btnAzurirajPodatkeArtikla_Click);
            // 
            // btnDodajArtikl
            // 
            this.btnDodajArtikl.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnDodajArtikl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnDodajArtikl.Location = new System.Drawing.Point(120, 295);
            this.btnDodajArtikl.Name = "btnDodajArtikl";
            this.btnDodajArtikl.Size = new System.Drawing.Size(109, 53);
            this.btnDodajArtikl.TabIndex = 41;
            this.btnDodajArtikl.Text = "DODAJ ARTIKL U BAZU";
            this.btnDodajArtikl.UseVisualStyleBackColor = false;
            this.btnDodajArtikl.Click += new System.EventHandler(this.btnDodajArtikl_Click);
            // 
            // btnIzlaz
            // 
            this.btnIzlaz.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnIzlaz.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnIzlaz.Location = new System.Drawing.Point(10, 9);
            this.btnIzlaz.Name = "btnIzlaz";
            this.btnIzlaz.Size = new System.Drawing.Size(39, 25);
            this.btnIzlaz.TabIndex = 40;
            this.btnIzlaz.Text = "<--";
            this.btnIzlaz.UseVisualStyleBackColor = false;
            this.btnIzlaz.Click += new System.EventHandler(this.btnIzlaz_Click);
            // 
            // inputPretraga
            // 
            this.inputPretraga.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.inputPretraga.Location = new System.Drawing.Point(477, 26);
            this.inputPretraga.Name = "inputPretraga";
            this.inputPretraga.Size = new System.Drawing.Size(100, 20);
            this.inputPretraga.TabIndex = 39;
            this.inputPretraga.TextChanged += new System.EventHandler(this.inputPretraga_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(353, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 13);
            this.label1.TabIndex = 38;
            this.label1.Text = "Pretraga po nazivu:";
            // 
            // dgvPrikazArtikala
            // 
            this.dgvPrikazArtikala.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPrikazArtikala.BackgroundColor = System.Drawing.SystemColors.ScrollBar;
            this.dgvPrikazArtikala.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPrikazArtikala.Location = new System.Drawing.Point(81, 61);
            this.dgvPrikazArtikala.Name = "dgvPrikazArtikala";
            this.dgvPrikazArtikala.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPrikazArtikala.Size = new System.Drawing.Size(496, 208);
            this.dgvPrikazArtikala.TabIndex = 37;
            this.dgvPrikazArtikala.SelectionChanged += new System.EventHandler(this.dgvPrikazArtikala_SelectionChanged);
            // 
            // lblKolicina
            // 
            this.lblKolicina.AutoSize = true;
            this.lblKolicina.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.lblKolicina.Location = new System.Drawing.Point(78, 21);
            this.lblKolicina.Name = "lblKolicina";
            this.lblKolicina.Size = new System.Drawing.Size(197, 13);
            this.lblKolicina.TabIndex = 86;
            this.lblKolicina.Text = "Kolicina na skladistu (odabranog artikla):";
            // 
            // FormaArtikli
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(663, 363);
            this.Controls.Add(this.lblKolicina);
            this.Controls.Add(this.btnIzbrisiArtikl);
            this.Controls.Add(this.btnAzurirajPodatkeArtikla);
            this.Controls.Add(this.btnDodajArtikl);
            this.Controls.Add(this.btnIzlaz);
            this.Controls.Add(this.inputPretraga);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgvPrikazArtikala);
            this.Name = "FormaArtikli";
            this.Text = "Prikaz artikala";
            this.Load += new System.EventHandler(this.FormaArtikli_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPrikazArtikala)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnIzbrisiArtikl;
        private System.Windows.Forms.Button btnAzurirajPodatkeArtikla;
        private System.Windows.Forms.Button btnDodajArtikl;
        private System.Windows.Forms.Button btnIzlaz;
        private System.Windows.Forms.TextBox inputPretraga;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvPrikazArtikala;
        private System.Windows.Forms.Label lblKolicina;
    }
}