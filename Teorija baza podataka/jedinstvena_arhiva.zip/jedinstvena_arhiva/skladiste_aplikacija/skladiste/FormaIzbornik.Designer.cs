﻿namespace skladiste
{
    partial class FormaIzbornik
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnPregledDostupnihArtikala = new System.Windows.Forms.Button();
            this.outputKorisnik = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnOdjava = new System.Windows.Forms.Button();
            this.btnUpravljanjeRacunima = new System.Windows.Forms.Button();
            this.btnUpravljanjePrimkama = new System.Windows.Forms.Button();
            this.btnIzradaPrimke = new System.Windows.Forms.Button();
            this.btnUpravljanjeNarudzbenicama = new System.Windows.Forms.Button();
            this.btnUpravljanjeArtiklima = new System.Windows.Forms.Button();
            this.btnUpravljanjeDobavljacima = new System.Windows.Forms.Button();
            this.btnUpravljanjeZaposlenicima = new System.Windows.Forms.Button();
            this.btnStanjeNaSkladistu = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnPregledDostupnihArtikala
            // 
            this.btnPregledDostupnihArtikala.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnPregledDostupnihArtikala.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnPregledDostupnihArtikala.Location = new System.Drawing.Point(44, 382);
            this.btnPregledDostupnihArtikala.Name = "btnPregledDostupnihArtikala";
            this.btnPregledDostupnihArtikala.Size = new System.Drawing.Size(114, 50);
            this.btnPregledDostupnihArtikala.TabIndex = 23;
            this.btnPregledDostupnihArtikala.Text = "PREGLED DOSTUPNIH ARTIKALA";
            this.btnPregledDostupnihArtikala.UseVisualStyleBackColor = false;
            this.btnPregledDostupnihArtikala.Click += new System.EventHandler(this.btnPregledDostupnihArtikala_Click);
            // 
            // outputKorisnik
            // 
            this.outputKorisnik.AutoSize = true;
            this.outputKorisnik.Location = new System.Drawing.Point(216, 16);
            this.outputKorisnik.Name = "outputKorisnik";
            this.outputKorisnik.Size = new System.Drawing.Size(0, 13);
            this.outputKorisnik.TabIndex = 22;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(117, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 13);
            this.label1.TabIndex = 21;
            this.label1.Text = "Trenutni korisnik:";
            // 
            // btnOdjava
            // 
            this.btnOdjava.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnOdjava.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnOdjava.Location = new System.Drawing.Point(8, 11);
            this.btnOdjava.Name = "btnOdjava";
            this.btnOdjava.Size = new System.Drawing.Size(79, 29);
            this.btnOdjava.TabIndex = 20;
            this.btnOdjava.Text = "ODJAVI SE";
            this.btnOdjava.UseVisualStyleBackColor = false;
            this.btnOdjava.Click += new System.EventHandler(this.btnOdjava_Click);
            // 
            // btnUpravljanjeRacunima
            // 
            this.btnUpravljanjeRacunima.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnUpravljanjeRacunima.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnUpravljanjeRacunima.Location = new System.Drawing.Point(44, 228);
            this.btnUpravljanjeRacunima.Name = "btnUpravljanjeRacunima";
            this.btnUpravljanjeRacunima.Size = new System.Drawing.Size(114, 49);
            this.btnUpravljanjeRacunima.TabIndex = 19;
            this.btnUpravljanjeRacunima.Text = "UPRAVLJANJE RAČUNIMA";
            this.btnUpravljanjeRacunima.UseVisualStyleBackColor = false;
            this.btnUpravljanjeRacunima.Click += new System.EventHandler(this.btnUpravljanjeRacunima_Click);
            // 
            // btnUpravljanjePrimkama
            // 
            this.btnUpravljanjePrimkama.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnUpravljanjePrimkama.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnUpravljanjePrimkama.Location = new System.Drawing.Point(44, 149);
            this.btnUpravljanjePrimkama.Name = "btnUpravljanjePrimkama";
            this.btnUpravljanjePrimkama.Size = new System.Drawing.Size(114, 49);
            this.btnUpravljanjePrimkama.TabIndex = 18;
            this.btnUpravljanjePrimkama.Text = "UPRAVLJANJE PRIMKAMA";
            this.btnUpravljanjePrimkama.UseVisualStyleBackColor = false;
            this.btnUpravljanjePrimkama.Click += new System.EventHandler(this.btnUpravljanjePrimkama_Click);
            // 
            // btnIzradaPrimke
            // 
            this.btnIzradaPrimke.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnIzradaPrimke.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnIzradaPrimke.Location = new System.Drawing.Point(44, 301);
            this.btnIzradaPrimke.Name = "btnIzradaPrimke";
            this.btnIzradaPrimke.Size = new System.Drawing.Size(114, 49);
            this.btnIzradaPrimke.TabIndex = 17;
            this.btnIzradaPrimke.Text = "IZRADA PRIMKE";
            this.btnIzradaPrimke.UseVisualStyleBackColor = false;
            this.btnIzradaPrimke.Click += new System.EventHandler(this.btnIzradaPrimke_Click);
            // 
            // btnUpravljanjeNarudzbenicama
            // 
            this.btnUpravljanjeNarudzbenicama.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnUpravljanjeNarudzbenicama.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnUpravljanjeNarudzbenicama.Location = new System.Drawing.Point(204, 149);
            this.btnUpravljanjeNarudzbenicama.Name = "btnUpravljanjeNarudzbenicama";
            this.btnUpravljanjeNarudzbenicama.Size = new System.Drawing.Size(131, 49);
            this.btnUpravljanjeNarudzbenicama.TabIndex = 16;
            this.btnUpravljanjeNarudzbenicama.Text = "UPRAVLJANJE NARUDŽBENICAMA";
            this.btnUpravljanjeNarudzbenicama.UseVisualStyleBackColor = false;
            this.btnUpravljanjeNarudzbenicama.Click += new System.EventHandler(this.btnUpravljanjeNarudzbenicama_Click);
            // 
            // btnUpravljanjeArtiklima
            // 
            this.btnUpravljanjeArtiklima.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnUpravljanjeArtiklima.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnUpravljanjeArtiklima.Location = new System.Drawing.Point(204, 228);
            this.btnUpravljanjeArtiklima.Name = "btnUpravljanjeArtiklima";
            this.btnUpravljanjeArtiklima.Size = new System.Drawing.Size(114, 49);
            this.btnUpravljanjeArtiklima.TabIndex = 14;
            this.btnUpravljanjeArtiklima.Text = "UPRAVLJANJE ARTIKLIMA NA SKLADIŠTU";
            this.btnUpravljanjeArtiklima.UseVisualStyleBackColor = false;
            this.btnUpravljanjeArtiklima.Click += new System.EventHandler(this.btnUpravljanjeArtiklima_Click);
            // 
            // btnUpravljanjeDobavljacima
            // 
            this.btnUpravljanjeDobavljacima.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnUpravljanjeDobavljacima.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnUpravljanjeDobavljacima.Location = new System.Drawing.Point(204, 74);
            this.btnUpravljanjeDobavljacima.Name = "btnUpravljanjeDobavljacima";
            this.btnUpravljanjeDobavljacima.Size = new System.Drawing.Size(114, 49);
            this.btnUpravljanjeDobavljacima.TabIndex = 13;
            this.btnUpravljanjeDobavljacima.Text = "UPRAVLJANJE DOBAVLJAČIMA";
            this.btnUpravljanjeDobavljacima.UseVisualStyleBackColor = false;
            this.btnUpravljanjeDobavljacima.Click += new System.EventHandler(this.btnUpravljanjeDobavljacima_Click);
            // 
            // btnUpravljanjeZaposlenicima
            // 
            this.btnUpravljanjeZaposlenicima.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnUpravljanjeZaposlenicima.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnUpravljanjeZaposlenicima.Location = new System.Drawing.Point(44, 74);
            this.btnUpravljanjeZaposlenicima.Name = "btnUpravljanjeZaposlenicima";
            this.btnUpravljanjeZaposlenicima.Size = new System.Drawing.Size(114, 49);
            this.btnUpravljanjeZaposlenicima.TabIndex = 12;
            this.btnUpravljanjeZaposlenicima.Text = "UPRAVLJANJE ZAPOSLENICIMA";
            this.btnUpravljanjeZaposlenicima.UseVisualStyleBackColor = false;
            this.btnUpravljanjeZaposlenicima.Click += new System.EventHandler(this.btnUpravljanjeZaposlenicima_Click);
            // 
            // btnStanjeNaSkladistu
            // 
            this.btnStanjeNaSkladistu.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnStanjeNaSkladistu.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnStanjeNaSkladistu.Location = new System.Drawing.Point(204, 300);
            this.btnStanjeNaSkladistu.Name = "btnStanjeNaSkladistu";
            this.btnStanjeNaSkladistu.Size = new System.Drawing.Size(114, 50);
            this.btnStanjeNaSkladistu.TabIndex = 24;
            this.btnStanjeNaSkladistu.Text = "STANJE NA SKLADIŠTU";
            this.btnStanjeNaSkladistu.UseVisualStyleBackColor = false;
            this.btnStanjeNaSkladistu.Click += new System.EventHandler(this.btnStanjeNaSkladistu_Click);
            // 
            // FormaIzbornik
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(371, 444);
            this.Controls.Add(this.btnStanjeNaSkladistu);
            this.Controls.Add(this.btnPregledDostupnihArtikala);
            this.Controls.Add(this.outputKorisnik);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnOdjava);
            this.Controls.Add(this.btnUpravljanjeRacunima);
            this.Controls.Add(this.btnUpravljanjePrimkama);
            this.Controls.Add(this.btnIzradaPrimke);
            this.Controls.Add(this.btnUpravljanjeNarudzbenicama);
            this.Controls.Add(this.btnUpravljanjeArtiklima);
            this.Controls.Add(this.btnUpravljanjeDobavljacima);
            this.Controls.Add(this.btnUpravljanjeZaposlenicima);
            this.Name = "FormaIzbornik";
            this.Text = "Glavni izbornik";
            this.Load += new System.EventHandler(this.FormaIzbornik_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnPregledDostupnihArtikala;
        private System.Windows.Forms.Label outputKorisnik;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnOdjava;
        private System.Windows.Forms.Button btnUpravljanjeRacunima;
        private System.Windows.Forms.Button btnUpravljanjePrimkama;
        private System.Windows.Forms.Button btnIzradaPrimke;
        private System.Windows.Forms.Button btnUpravljanjeNarudzbenicama;
        private System.Windows.Forms.Button btnUpravljanjeArtiklima;
        private System.Windows.Forms.Button btnUpravljanjeDobavljacima;
        private System.Windows.Forms.Button btnUpravljanjeZaposlenicima;
        private System.Windows.Forms.Button btnStanjeNaSkladistu;
    }
}