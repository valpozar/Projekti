﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace skladiste
{
    public partial class FormaZaposlenici : Form
    {
        public FormaZaposlenici()
        {
            InitializeComponent();
        }

        private void btnIzlaz_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormaIzbornik formaIzbornik = new FormaIzbornik();
            formaIzbornik.FormClosed += (s, args) => this.Close();
            formaIzbornik.ShowDialog();
        }

        private void OsvjeziZaposlenike()
        {

            List<Korisnik> listaZaposlenika = Korisnik.DohvacanjeZaposlenika(inputPretraga.Text);
            dgvPrikazZaposlenika.DataSource = listaZaposlenika;
        }

        private void FormaZaposlenici_Load(object sender, EventArgs e)
        {
            OsvjeziZaposlenike();
        }

        private void inputPretraga_TextChanged(object sender, EventArgs e)
        {
            OsvjeziZaposlenike();
        }

        private void btnIzbrisiZaposlenika_Click(object sender, EventArgs e)
        {
            if (dgvPrikazZaposlenika.SelectedRows.Count > 0)
            {
                foreach (DataGridViewRow row in dgvPrikazZaposlenika.SelectedRows)
                {
                    Korisnik odabraniZaposlenik = row.DataBoundItem as Korisnik;
                    odabraniZaposlenik.BrisanjeZaposlenika();
                }

                MessageBox.Show("Uspješno brisanje zaposlenika!", "Uspješno brisanje zaposlenika!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Morate odabrati zaposlenika!", "Upozorenje!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            OsvjeziZaposlenike();
        }

        private void btnAzurirajPodatkeZaposlenika_Click(object sender, EventArgs e)
        {
            if (dgvPrikazZaposlenika.SelectedRows.Count > 0)
            {
                Korisnik odabraniZaposlenik = dgvPrikazZaposlenika.SelectedRows[0].DataBoundItem as Korisnik;

                this.Hide();
                FormaAzuriranjeZaposlenika formaAzuriranjeZaposlenika = new FormaAzuriranjeZaposlenika(odabraniZaposlenik);
                formaAzuriranjeZaposlenika.Closed += (s, args) => this.Close();
                formaAzuriranjeZaposlenika.ShowDialog();
                OsvjeziZaposlenike();
            }
            else
            {
                MessageBox.Show("Morate odabrati zaposlenika!", "Upozorenje!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnDodajZaposlenika_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormaUnosZaposlenika formaUnosZaposlenika = new FormaUnosZaposlenika();
            formaUnosZaposlenika.Closed += (s, args) => this.Close();
            formaUnosZaposlenika.ShowDialog();
            OsvjeziZaposlenike();
        }
    }
}
