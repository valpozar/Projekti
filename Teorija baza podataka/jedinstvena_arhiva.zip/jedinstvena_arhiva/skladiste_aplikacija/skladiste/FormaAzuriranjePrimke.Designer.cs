﻿namespace skladiste
{
    partial class FormaAzuriranjePrimke
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnIzlaz = new System.Windows.Forms.Button();
            this.dtpDatum = new System.Windows.Forms.DateTimePicker();
            this.inputIdNarudzbenice = new System.Windows.Forms.TextBox();
            this.inputIdKorisnika = new System.Windows.Forms.TextBox();
            this.inputUkupniIznos = new System.Windows.Forms.TextBox();
            this.inputNapomena = new System.Windows.Forms.TextBox();
            this.inputBrojOtpremnice = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.outputId = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnAzuriraj = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnIzlaz
            // 
            this.btnIzlaz.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnIzlaz.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIzlaz.Location = new System.Drawing.Point(12, 12);
            this.btnIzlaz.Name = "btnIzlaz";
            this.btnIzlaz.Size = new System.Drawing.Size(39, 25);
            this.btnIzlaz.TabIndex = 96;
            this.btnIzlaz.Text = "<--";
            this.btnIzlaz.UseVisualStyleBackColor = false;
            this.btnIzlaz.Click += new System.EventHandler(this.btnIzlaz_Click);
            // 
            // dtpDatum
            // 
            this.dtpDatum.CalendarMonthBackground = System.Drawing.SystemColors.ScrollBar;
            this.dtpDatum.Location = new System.Drawing.Point(207, 247);
            this.dtpDatum.Name = "dtpDatum";
            this.dtpDatum.Size = new System.Drawing.Size(148, 20);
            this.dtpDatum.TabIndex = 110;
            // 
            // inputIdNarudzbenice
            // 
            this.inputIdNarudzbenice.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.inputIdNarudzbenice.Location = new System.Drawing.Point(207, 212);
            this.inputIdNarudzbenice.Name = "inputIdNarudzbenice";
            this.inputIdNarudzbenice.Size = new System.Drawing.Size(148, 20);
            this.inputIdNarudzbenice.TabIndex = 109;
            // 
            // inputIdKorisnika
            // 
            this.inputIdKorisnika.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.inputIdKorisnika.Location = new System.Drawing.Point(207, 182);
            this.inputIdKorisnika.Name = "inputIdKorisnika";
            this.inputIdKorisnika.Size = new System.Drawing.Size(148, 20);
            this.inputIdKorisnika.TabIndex = 108;
            // 
            // inputUkupniIznos
            // 
            this.inputUkupniIznos.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.inputUkupniIznos.Location = new System.Drawing.Point(207, 149);
            this.inputUkupniIznos.Name = "inputUkupniIznos";
            this.inputUkupniIznos.Size = new System.Drawing.Size(148, 20);
            this.inputUkupniIznos.TabIndex = 107;
            // 
            // inputNapomena
            // 
            this.inputNapomena.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.inputNapomena.Location = new System.Drawing.Point(207, 117);
            this.inputNapomena.Name = "inputNapomena";
            this.inputNapomena.Size = new System.Drawing.Size(148, 20);
            this.inputNapomena.TabIndex = 106;
            // 
            // inputBrojOtpremnice
            // 
            this.inputBrojOtpremnice.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.inputBrojOtpremnice.Location = new System.Drawing.Point(207, 82);
            this.inputBrojOtpremnice.Name = "inputBrojOtpremnice";
            this.inputBrojOtpremnice.Size = new System.Drawing.Size(148, 20);
            this.inputBrojOtpremnice.TabIndex = 105;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label7.Location = new System.Drawing.Point(63, 212);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(125, 13);
            this.label7.TabIndex = 104;
            this.label7.Text = "ID NARUDŽBENICE:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.Location = new System.Drawing.Point(63, 182);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(95, 13);
            this.label6.TabIndex = 103;
            this.label6.Text = "ID KORISNIKA:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.Location = new System.Drawing.Point(63, 149);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(104, 13);
            this.label5.TabIndex = 102;
            this.label5.Text = "UKUPAN IZNOS:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(63, 117);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 13);
            this.label4.TabIndex = 101;
            this.label4.Text = "NAPOMENA:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(63, 82);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(128, 13);
            this.label3.TabIndex = 100;
            this.label3.Text = "BROJ OTPREMNICE:";
            // 
            // outputId
            // 
            this.outputId.AutoSize = true;
            this.outputId.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.outputId.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.outputId.Location = new System.Drawing.Point(204, 42);
            this.outputId.Name = "outputId";
            this.outputId.Size = new System.Drawing.Size(18, 13);
            this.outputId.TabIndex = 98;
            this.outputId.Text = "Id";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(100, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 97;
            this.label1.Text = "Primka:";
            // 
            // btnAzuriraj
            // 
            this.btnAzuriraj.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnAzuriraj.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnAzuriraj.Location = new System.Drawing.Point(146, 284);
            this.btnAzuriraj.Name = "btnAzuriraj";
            this.btnAzuriraj.Size = new System.Drawing.Size(106, 44);
            this.btnAzuriraj.TabIndex = 111;
            this.btnAzuriraj.Text = "AŽURIRAJ";
            this.btnAzuriraj.UseVisualStyleBackColor = false;
            this.btnAzuriraj.Click += new System.EventHandler(this.btnAzuriraj_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(63, 247);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 112;
            this.label2.Text = "DATUM:";
            // 
            // FormaAzuriranjePrimke
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(399, 340);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnAzuriraj);
            this.Controls.Add(this.dtpDatum);
            this.Controls.Add(this.inputIdNarudzbenice);
            this.Controls.Add(this.inputIdKorisnika);
            this.Controls.Add(this.inputUkupniIznos);
            this.Controls.Add(this.inputNapomena);
            this.Controls.Add(this.inputBrojOtpremnice);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.outputId);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnIzlaz);
            this.Name = "FormaAzuriranjePrimke";
            this.Text = "Ažuriranje primke";
            this.Load += new System.EventHandler(this.FormaAzuriranjePrimke_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnIzlaz;
        private System.Windows.Forms.DateTimePicker dtpDatum;
        private System.Windows.Forms.TextBox inputIdNarudzbenice;
        private System.Windows.Forms.TextBox inputIdKorisnika;
        private System.Windows.Forms.TextBox inputUkupniIznos;
        private System.Windows.Forms.TextBox inputNapomena;
        private System.Windows.Forms.TextBox inputBrojOtpremnice;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label outputId;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnAzuriraj;
        private System.Windows.Forms.Label label2;
    }
}