﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Common;

namespace skladiste
{
    public class Narudzbenica
    {
        public int IdNarudzbenice { get; set; }
        public DateTime Datum { get; set; }
        public string Napomena { get; set; }
        public float UkupniIznos { get; set; }

        public Narudzbenica()
        {

        }

        public Narudzbenica(DbDataReader podaci)
        {
            if (podaci != null)
            {

                IdNarudzbenice = int.Parse(podaci["id_narudzbenice"].ToString());
                Datum = DateTime.Parse(podaci["datum"].ToString());
                Napomena = podaci["napomena"].ToString();
                UkupniIznos = float.Parse(podaci["ukupan_iznos"].ToString());
            }
        }

        public static List<Narudzbenica> DohvatiNarudzbenice()
        {
            List<Narudzbenica> lista = new List<Narudzbenica>();
            string sqlUpit = "SELECT * FROM narudzbenica";
            DbDataReader dr = DB.Instance.DohvatiDataReader(sqlUpit);
            while (dr.Read())
            {

                Narudzbenica narudzbenica = new Narudzbenica(dr);
                lista.Add(narudzbenica);
            }
            dr.Close();
            return lista;
        }

        public static List<Narudzbenica> DohvatiPretrazeneNarudzbenice(int pretraga)
        {
            List<Narudzbenica> lista = new List<Narudzbenica>();
            string sqlUpit = "SELECT * FROM narudzbenica WHERE id_narudzbenice = " + pretraga;
            DbDataReader dr = DB.Instance.DohvatiDataReader(sqlUpit);
            while (dr.Read())
            {

                Narudzbenica narudzbenica = new Narudzbenica(dr);
                lista.Add(narudzbenica);
            }
            dr.Close();
            return lista;
        }

        public void BrisanjeNarudzbenice()
        {
            string sqlUpit = "DELETE FROM narudzbenica WHERE  id_narudzbenice = " + this.IdNarudzbenice;
            DB.Instance.IzvrsiUpit(sqlUpit);
        }

        public void AzuriranjeNarudzbenice(int id, DateTime datum, string napomena, float ukupniIznos)
        {
            string sqlUpit = "UPDATE narudzbenica SET datum = default, napomena = '" + napomena + "' , ukupan_iznos = '" + ukupniIznos + "'WHERE id_narudzbenice = " + id;
            DB.Instance.IzvrsiUpit(sqlUpit);
        }
    }
}
