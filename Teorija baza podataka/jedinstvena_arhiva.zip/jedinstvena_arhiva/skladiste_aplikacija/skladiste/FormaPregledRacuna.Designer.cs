﻿namespace skladiste
{
    partial class FormaPregledRacuna
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.actionAzurirajRacun = new System.Windows.Forms.Button();
            this.actionObrisiRacun = new System.Windows.Forms.Button();
            this.actionSviRacuni = new System.Windows.Forms.Button();
            this.dgvStavkaRacuna = new System.Windows.Forms.DataGridView();
            this.actionPretrazi = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.inputIdRacuna = new System.Windows.Forms.TextBox();
            this.dgvRacuni = new System.Windows.Forms.DataGridView();
            this.btnIzlaz = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStavkaRacuna)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRacuni)).BeginInit();
            this.SuspendLayout();
            // 
            // actionAzurirajRacun
            // 
            this.actionAzurirajRacun.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.actionAzurirajRacun.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.actionAzurirajRacun.Location = new System.Drawing.Point(731, 118);
            this.actionAzurirajRacun.Name = "actionAzurirajRacun";
            this.actionAzurirajRacun.Size = new System.Drawing.Size(99, 32);
            this.actionAzurirajRacun.TabIndex = 69;
            this.actionAzurirajRacun.Text = "Ažuriraj račun";
            this.actionAzurirajRacun.UseVisualStyleBackColor = false;
            this.actionAzurirajRacun.Click += new System.EventHandler(this.actionAzurirajRacun_Click);
            // 
            // actionObrisiRacun
            // 
            this.actionObrisiRacun.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.actionObrisiRacun.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.actionObrisiRacun.Location = new System.Drawing.Point(731, 66);
            this.actionObrisiRacun.Name = "actionObrisiRacun";
            this.actionObrisiRacun.Size = new System.Drawing.Size(99, 32);
            this.actionObrisiRacun.TabIndex = 68;
            this.actionObrisiRacun.Text = "Obriši račun";
            this.actionObrisiRacun.UseVisualStyleBackColor = false;
            this.actionObrisiRacun.Click += new System.EventHandler(this.actionObrisiRacun_Click);
            // 
            // actionSviRacuni
            // 
            this.actionSviRacuni.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.actionSviRacuni.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.actionSviRacuni.Location = new System.Drawing.Point(608, 25);
            this.actionSviRacuni.Name = "actionSviRacuni";
            this.actionSviRacuni.Size = new System.Drawing.Size(83, 23);
            this.actionSviRacuni.TabIndex = 67;
            this.actionSviRacuni.Text = "Svi računi";
            this.actionSviRacuni.UseVisualStyleBackColor = false;
            this.actionSviRacuni.Click += new System.EventHandler(this.actionSviRacuni_Click);
            // 
            // dgvStavkaRacuna
            // 
            this.dgvStavkaRacuna.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvStavkaRacuna.BackgroundColor = System.Drawing.SystemColors.ScrollBar;
            this.dgvStavkaRacuna.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvStavkaRacuna.DefaultCellStyle = dataGridViewCellStyle1;
            this.dgvStavkaRacuna.Location = new System.Drawing.Point(18, 281);
            this.dgvStavkaRacuna.Name = "dgvStavkaRacuna";
            this.dgvStavkaRacuna.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvStavkaRacuna.Size = new System.Drawing.Size(673, 198);
            this.dgvStavkaRacuna.TabIndex = 66;
            // 
            // actionPretrazi
            // 
            this.actionPretrazi.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.actionPretrazi.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.actionPretrazi.Location = new System.Drawing.Point(502, 25);
            this.actionPretrazi.Name = "actionPretrazi";
            this.actionPretrazi.Size = new System.Drawing.Size(75, 23);
            this.actionPretrazi.TabIndex = 64;
            this.actionPretrazi.Text = "Pretraži";
            this.actionPretrazi.UseVisualStyleBackColor = false;
            this.actionPretrazi.Click += new System.EventHandler(this.actionPretrazi_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label1.Location = new System.Drawing.Point(355, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 63;
            this.label1.Text = "ID računa:";
            // 
            // inputIdRacuna
            // 
            this.inputIdRacuna.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.inputIdRacuna.Location = new System.Drawing.Point(418, 27);
            this.inputIdRacuna.Name = "inputIdRacuna";
            this.inputIdRacuna.Size = new System.Drawing.Size(60, 20);
            this.inputIdRacuna.TabIndex = 62;
            // 
            // dgvRacuni
            // 
            this.dgvRacuni.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvRacuni.BackgroundColor = System.Drawing.SystemColors.ScrollBar;
            this.dgvRacuni.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvRacuni.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvRacuni.Location = new System.Drawing.Point(18, 66);
            this.dgvRacuni.Name = "dgvRacuni";
            this.dgvRacuni.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvRacuni.Size = new System.Drawing.Size(673, 198);
            this.dgvRacuni.TabIndex = 61;
            this.dgvRacuni.SelectionChanged += new System.EventHandler(this.dgvRacuni_SelectionChanged);
            // 
            // btnIzlaz
            // 
            this.btnIzlaz.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnIzlaz.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIzlaz.Location = new System.Drawing.Point(12, 12);
            this.btnIzlaz.Name = "btnIzlaz";
            this.btnIzlaz.Size = new System.Drawing.Size(39, 25);
            this.btnIzlaz.TabIndex = 70;
            this.btnIzlaz.Text = "<--";
            this.btnIzlaz.UseVisualStyleBackColor = false;
            this.btnIzlaz.Click += new System.EventHandler(this.btnIzlaz_Click);
            // 
            // FormaPregledRacuna
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(862, 521);
            this.Controls.Add(this.btnIzlaz);
            this.Controls.Add(this.actionAzurirajRacun);
            this.Controls.Add(this.actionObrisiRacun);
            this.Controls.Add(this.actionSviRacuni);
            this.Controls.Add(this.dgvStavkaRacuna);
            this.Controls.Add(this.actionPretrazi);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.inputIdRacuna);
            this.Controls.Add(this.dgvRacuni);
            this.Name = "FormaPregledRacuna";
            this.Text = "Pregled računa";
            this.Load += new System.EventHandler(this.FormaPregledRacuna_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvStavkaRacuna)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRacuni)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button actionAzurirajRacun;
        private System.Windows.Forms.Button actionObrisiRacun;
        private System.Windows.Forms.Button actionSviRacuni;
        private System.Windows.Forms.DataGridView dgvStavkaRacuna;
        private System.Windows.Forms.Button actionPretrazi;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox inputIdRacuna;
        private System.Windows.Forms.DataGridView dgvRacuni;
        private System.Windows.Forms.Button btnIzlaz;
    }
}