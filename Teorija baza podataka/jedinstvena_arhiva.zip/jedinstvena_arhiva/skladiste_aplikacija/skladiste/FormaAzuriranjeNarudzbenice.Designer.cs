﻿namespace skladiste
{
    partial class FormaAzuriranjeNarudzbenice
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAzuriraj = new System.Windows.Forms.Button();
            this.dtpDatum = new System.Windows.Forms.DateTimePicker();
            this.inputUkupniIznos = new System.Windows.Forms.TextBox();
            this.inputNapomena = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.outputId = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnIzlaz = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnAzuriraj
            // 
            this.btnAzuriraj.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnAzuriraj.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnAzuriraj.Location = new System.Drawing.Point(143, 281);
            this.btnAzuriraj.Name = "btnAzuriraj";
            this.btnAzuriraj.Size = new System.Drawing.Size(106, 44);
            this.btnAzuriraj.TabIndex = 127;
            this.btnAzuriraj.Text = "AŽURIRAJ";
            this.btnAzuriraj.UseVisualStyleBackColor = false;
            this.btnAzuriraj.Click += new System.EventHandler(this.btnAzuriraj_Click);
            // 
            // dtpDatum
            // 
            this.dtpDatum.CalendarMonthBackground = System.Drawing.SystemColors.ScrollBar;
            this.dtpDatum.Location = new System.Drawing.Point(199, 190);
            this.dtpDatum.Name = "dtpDatum";
            this.dtpDatum.Size = new System.Drawing.Size(148, 20);
            this.dtpDatum.TabIndex = 126;
            // 
            // inputUkupniIznos
            // 
            this.inputUkupniIznos.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.inputUkupniIznos.Location = new System.Drawing.Point(199, 153);
            this.inputUkupniIznos.Name = "inputUkupniIznos";
            this.inputUkupniIznos.Size = new System.Drawing.Size(148, 20);
            this.inputUkupniIznos.TabIndex = 123;
            // 
            // inputNapomena
            // 
            this.inputNapomena.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.inputNapomena.Location = new System.Drawing.Point(199, 118);
            this.inputNapomena.Name = "inputNapomena";
            this.inputNapomena.Size = new System.Drawing.Size(148, 20);
            this.inputNapomena.TabIndex = 122;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.Location = new System.Drawing.Point(55, 153);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(104, 13);
            this.label5.TabIndex = 118;
            this.label5.Text = "UKUPAN IZNOS:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(55, 118);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 13);
            this.label4.TabIndex = 117;
            this.label4.Text = "NAPOMENA:";
            // 
            // outputId
            // 
            this.outputId.AutoSize = true;
            this.outputId.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.outputId.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.outputId.Location = new System.Drawing.Point(244, 41);
            this.outputId.Name = "outputId";
            this.outputId.Size = new System.Drawing.Size(18, 13);
            this.outputId.TabIndex = 114;
            this.outputId.Text = "Id";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(140, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 13);
            this.label1.TabIndex = 113;
            this.label1.Text = "Narudžbenica:";
            // 
            // btnIzlaz
            // 
            this.btnIzlaz.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnIzlaz.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIzlaz.Location = new System.Drawing.Point(9, 9);
            this.btnIzlaz.Name = "btnIzlaz";
            this.btnIzlaz.Size = new System.Drawing.Size(39, 25);
            this.btnIzlaz.TabIndex = 112;
            this.btnIzlaz.Text = "<--";
            this.btnIzlaz.UseVisualStyleBackColor = false;
            this.btnIzlaz.Click += new System.EventHandler(this.btnIzlaz_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(55, 190);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 128;
            this.label2.Text = "DATUM:";
            // 
            // FormaAzuriranjeNarudzbenice
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(399, 340);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnAzuriraj);
            this.Controls.Add(this.dtpDatum);
            this.Controls.Add(this.inputUkupniIznos);
            this.Controls.Add(this.inputNapomena);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.outputId);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnIzlaz);
            this.Name = "FormaAzuriranjeNarudzbenice";
            this.Text = "Ažuriranje narudžbenice";
            this.Load += new System.EventHandler(this.FormaAzuriranjeNarudzbenice_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAzuriraj;
        private System.Windows.Forms.DateTimePicker dtpDatum;
        private System.Windows.Forms.TextBox inputUkupniIznos;
        private System.Windows.Forms.TextBox inputNapomena;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label outputId;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnIzlaz;
        private System.Windows.Forms.Label label2;
    }
}