﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace skladiste
{
    public partial class FormaStanjeNaSkladistu : Form
    {
        public FormaStanjeNaSkladistu()
        {
            InitializeComponent();
        }

        private void btnIzlaz_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormaIzbornik formaIzbornik = new FormaIzbornik();
            formaIzbornik.FormClosed += (s, args) => this.Close();
            formaIzbornik.ShowDialog();
        }

        private void OsvjeziStanjeNaSkladistu()
        {
            List<Skladiste> listaStanjaNaSkladistu = Skladiste.DohvatiStanjeNaSkladistu();
            dgvPrikazStanjaNaSkladistu.DataSource = listaStanjaNaSkladistu;
        }

        private void FormaStanjeNaSkladistu_Load(object sender, EventArgs e)
        {
            OsvjeziStanjeNaSkladistu();
        }
    }
}
