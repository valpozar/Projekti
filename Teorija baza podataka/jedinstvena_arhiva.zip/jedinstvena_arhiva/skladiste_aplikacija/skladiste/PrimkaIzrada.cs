﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Common;

namespace skladiste
{
    public class PrimkaIzrada
    {
        public int IdPrimke { get; set; }

        public PrimkaIzrada(DbDataReader podaci)
        {
            if (podaci != null)
            {
                IdPrimke = int.Parse(podaci["id_primke"].ToString());
            }
        }

        public static List<PrimkaIzrada> DohvatiIdPrimke()
        {
            List<PrimkaIzrada> lista = new List<PrimkaIzrada>();
            string sqlUpit = "SELECT id_primke FROM primka";
            DbDataReader dr = DB.Instance.DohvatiDataReader(sqlUpit);
            while (dr.Read())
            {

                PrimkaIzrada primka = new PrimkaIzrada(dr);
                lista.Add(primka);
            }
            dr.Close();
            return lista;
        }

        public override string ToString()
        {
            return IdPrimke.ToString();
        }
    }
}
