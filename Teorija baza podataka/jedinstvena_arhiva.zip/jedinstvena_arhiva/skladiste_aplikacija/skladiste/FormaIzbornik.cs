﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace skladiste
{
    public partial class FormaIzbornik : Form
    {
        private Korisnik trenutniKorisnik = FormaPrijava.Korisnik;

        public FormaIzbornik()
        {
            InitializeComponent();
        }

        private void btnOdjava_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormaPrijava formaPrijava = new FormaPrijava();
            formaPrijava.FormClosed += (s, args) => this.Close();
            formaPrijava.ShowDialog();
        }

        private void FormaIzbornik_Load(object sender, EventArgs e)
        {
            outputKorisnik.Text = trenutniKorisnik.Ime + " " + trenutniKorisnik.Prezime;
            outputKorisnik.ForeColor = Color.White;

            if (trenutniKorisnik.IDVrsteKorisnika == 3)
            {
                btnUpravljanjeZaposlenicima.Enabled = false;
                btnUpravljanjeRacunima.Enabled = false;
                btnUpravljanjePrimkama.Enabled = false;
                btnUpravljanjeNarudzbenicama.Enabled = false;
                btnUpravljanjeDobavljacima.Enabled = false;
                btnUpravljanjeArtiklima.Enabled = false;
                btnIzradaPrimke.Enabled = false;
                btnStanjeNaSkladistu.Enabled = false;
            }
            else if (trenutniKorisnik.IDVrsteKorisnika == 2)
            {
                btnUpravljanjeZaposlenicima.Enabled = false;
                btnUpravljanjeRacunima.Enabled = false;
                btnUpravljanjePrimkama.Enabled = false;
                btnUpravljanjeNarudzbenicama.Enabled = false;
                btnUpravljanjeDobavljacima.Enabled = false;
            }
        }

        private void btnUpravljanjeDobavljacima_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormaDobavljaci formaDobavljaci = new FormaDobavljaci();
            formaDobavljaci.FormClosed += (s, args) => this.Close();
            formaDobavljaci.ShowDialog();
        }

        private void btnUpravljanjeZaposlenicima_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormaZaposlenici formaZaposlenici = new FormaZaposlenici();
            formaZaposlenici.FormClosed += (s, args) => this.Close();
            formaZaposlenici.ShowDialog();
        }

        private void btnPregledDostupnihArtikala_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormaDostupniArtikli formaDostupniArtikli = new FormaDostupniArtikli();
            formaDostupniArtikli.FormClosed += (s, args) => this.Close();
            formaDostupniArtikli.ShowDialog();
        }

        private void btnUpravljanjeRacunima_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormaPregledRacuna formaPregledRacuna = new FormaPregledRacuna();
            formaPregledRacuna.FormClosed += (s, args) => this.Close();
            formaPregledRacuna.ShowDialog();
        }

        private void btnUpravljanjeArtiklima_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormaArtikli formaArtikli = new FormaArtikli();
            formaArtikli.FormClosed += (s, args) => this.Close();
            formaArtikli.ShowDialog();
        }

        private void btnIzradaPrimke_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormaIzradaPrimke formaIzradaPrimke = new FormaIzradaPrimke(trenutniKorisnik.IDKorisnika);
            formaIzradaPrimke.FormClosed += (s, args) => this.Close();
            formaIzradaPrimke.ShowDialog();
        }

        private void btnUpravljanjePrimkama_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormaPregledPrimki formaPregledPrimki = new FormaPregledPrimki();
            formaPregledPrimki.FormClosed += (s, args) => this.Close();
            formaPregledPrimki.ShowDialog();
        }

        private void btnUpravljanjeNarudzbenicama_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormaPregledNarudzbenica formaPregledNarudzbenica = new FormaPregledNarudzbenica();
            formaPregledNarudzbenica.FormClosed += (s, args) => this.Close();
            formaPregledNarudzbenica.ShowDialog();
        }

        private void btnStanjeNaSkladistu_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormaStanjeNaSkladistu formaPregledStanjaNaSkladistu = new FormaStanjeNaSkladistu();
            formaPregledStanjaNaSkladistu.FormClosed += (s, args) => this.Close();
            formaPregledStanjaNaSkladistu.ShowDialog();
        }
    }
}
