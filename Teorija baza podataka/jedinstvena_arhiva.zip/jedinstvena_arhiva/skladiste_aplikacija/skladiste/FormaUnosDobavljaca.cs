﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace skladiste
{
    public partial class FormaUnosDobavljaca : Form
    {
        private Dobavljac dobavljac = null;
        private string naziv = "";
        private string adresa = "";
        private string kontakt = "";

        public FormaUnosDobavljaca()
        {
            InitializeComponent();
        }

        private void btnUnesiDobavljaca_Click(object sender, EventArgs e)
        {
            naziv = inputNaziv.Text;
            adresa = inputAdresa.Text;
            kontakt = inputKontakt.Text;

            int postojiNaziv = 0;

            if (String.IsNullOrWhiteSpace(naziv) || String.IsNullOrWhiteSpace(adresa) || String.IsNullOrWhiteSpace(kontakt))
            {
                MessageBox.Show("Morate unijeti sve podatke!", "Upozorenje!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                postojiNaziv = Dobavljac.ProvjeraNaziva(naziv);
                if (postojiNaziv == 1)
                {
                    MessageBox.Show("Uneseni naziv već postoji!", "Upozorenje!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    dobavljac = new Dobavljac(naziv, adresa, kontakt);
                    dobavljac.SpremanjeDobavljaca();

                    MessageBox.Show("Uspješan unos dobavljača!", "Uspješno dodavanje dobavljača!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    this.Hide();
                    FormaDobavljaci formaDobavljaci = new FormaDobavljaci();
                    formaDobavljaci.Closed += (s, args) => this.Close();
                    formaDobavljaci.ShowDialog();
                }
            }
        }

        private void btnIzlaz_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormaDobavljaci formaDobavljaci = new FormaDobavljaci();
            formaDobavljaci.FormClosed += (s, args) => this.Close();
            formaDobavljaci.ShowDialog();
        }
    }
}
