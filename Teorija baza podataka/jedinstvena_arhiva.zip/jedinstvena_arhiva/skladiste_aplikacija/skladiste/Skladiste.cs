﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;

namespace skladiste
{
    public class Skladiste
    {
        public ArtiklUpravljanje NazivArtikla { get; set; }
        public int Kolicina { get; set; }
        public int IdArtikla;

        public Skladiste(int idartikla, int kolicina)
        {
            IdArtikla = idartikla;
            Kolicina = kolicina;
        }

        public Skladiste(DbDataReader podaci)
        {
            if (podaci != null)
            {
                Kolicina = int.Parse(podaci["kolicina"].ToString());
                NazivArtikla = new ArtiklUpravljanje();
                NazivArtikla.IdArtikla = int.Parse(podaci["id_artikla"].ToString());
                NazivArtikla.Naziv = podaci["naziv"].ToString();
            }
        }

        public static List<Skladiste> DohvatiStanjeNaSkladistu()
        {
            List<Skladiste> lista = new List<Skladiste>();
            string sqlUpit = "SELECT a.id_artikla, a.naziv, s.kolicina FROM artikl a JOIN skladiste s ON a.id_artikla=s.id_artikla";
            DbDataReader dr = DB.Instance.DohvatiDataReader(sqlUpit);
            while (dr.Read())
            {

                Skladiste skladiste = new Skladiste(dr);
                lista.Add(skladiste);
            }
            dr.Close();
            return lista;
        }
    }
}
