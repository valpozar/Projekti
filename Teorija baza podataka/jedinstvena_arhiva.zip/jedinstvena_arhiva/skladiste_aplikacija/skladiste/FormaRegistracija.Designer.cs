﻿namespace skladiste
{
    partial class FormaRegistracija
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnRegistrirajSe = new System.Windows.Forms.Button();
            this.btnIzlaz = new System.Windows.Forms.Button();
            this.inputKontakt = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.inputAdresa = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.inputPotvrdaLozinke = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.inputLozinka = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.inputEmail = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.inputPrezime = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.inputIme = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnRegistrirajSe
            // 
            this.btnRegistrirajSe.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnRegistrirajSe.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnRegistrirajSe.Location = new System.Drawing.Point(145, 387);
            this.btnRegistrirajSe.Name = "btnRegistrirajSe";
            this.btnRegistrirajSe.Size = new System.Drawing.Size(106, 44);
            this.btnRegistrirajSe.TabIndex = 34;
            this.btnRegistrirajSe.Text = "REGISTRIRAJ SE";
            this.btnRegistrirajSe.UseVisualStyleBackColor = false;
            this.btnRegistrirajSe.Click += new System.EventHandler(this.btnRegistrirajSe_Click);
            // 
            // btnIzlaz
            // 
            this.btnIzlaz.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnIzlaz.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIzlaz.Location = new System.Drawing.Point(11, 10);
            this.btnIzlaz.Name = "btnIzlaz";
            this.btnIzlaz.Size = new System.Drawing.Size(39, 25);
            this.btnIzlaz.TabIndex = 33;
            this.btnIzlaz.Text = "<--";
            this.btnIzlaz.UseVisualStyleBackColor = false;
            this.btnIzlaz.Click += new System.EventHandler(this.btnIzlaz_Click);
            // 
            // inputKontakt
            // 
            this.inputKontakt.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.inputKontakt.Location = new System.Drawing.Point(205, 330);
            this.inputKontakt.Name = "inputKontakt";
            this.inputKontakt.Size = new System.Drawing.Size(140, 20);
            this.inputKontakt.TabIndex = 32;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label7.Location = new System.Drawing.Point(71, 330);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 13);
            this.label7.TabIndex = 31;
            this.label7.Text = "KONTAKT:";
            // 
            // inputAdresa
            // 
            this.inputAdresa.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.inputAdresa.Location = new System.Drawing.Point(205, 284);
            this.inputAdresa.Name = "inputAdresa";
            this.inputAdresa.Size = new System.Drawing.Size(140, 20);
            this.inputAdresa.TabIndex = 30;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.Location = new System.Drawing.Point(71, 284);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 13);
            this.label6.TabIndex = 29;
            this.label6.Text = "ADRESA:";
            // 
            // inputPotvrdaLozinke
            // 
            this.inputPotvrdaLozinke.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.inputPotvrdaLozinke.Location = new System.Drawing.Point(205, 241);
            this.inputPotvrdaLozinke.Name = "inputPotvrdaLozinke";
            this.inputPotvrdaLozinke.Size = new System.Drawing.Size(140, 20);
            this.inputPotvrdaLozinke.TabIndex = 28;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.Location = new System.Drawing.Point(71, 241);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(127, 13);
            this.label5.TabIndex = 27;
            this.label5.Text = "POTVRDA LOZINKE:";
            // 
            // inputLozinka
            // 
            this.inputLozinka.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.inputLozinka.Location = new System.Drawing.Point(205, 197);
            this.inputLozinka.Name = "inputLozinka";
            this.inputLozinka.Size = new System.Drawing.Size(140, 20);
            this.inputLozinka.TabIndex = 26;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(71, 197);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 13);
            this.label4.TabIndex = 25;
            this.label4.Text = "LOZINKA:";
            // 
            // inputEmail
            // 
            this.inputEmail.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.inputEmail.Location = new System.Drawing.Point(205, 154);
            this.inputEmail.Name = "inputEmail";
            this.inputEmail.Size = new System.Drawing.Size(140, 20);
            this.inputEmail.TabIndex = 24;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(71, 154);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 13);
            this.label3.TabIndex = 23;
            this.label3.Text = "E-MAIL:";
            // 
            // inputPrezime
            // 
            this.inputPrezime.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.inputPrezime.Location = new System.Drawing.Point(205, 115);
            this.inputPrezime.Name = "inputPrezime";
            this.inputPrezime.Size = new System.Drawing.Size(140, 20);
            this.inputPrezime.TabIndex = 22;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(71, 115);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 13);
            this.label2.TabIndex = 21;
            this.label2.Text = "PREZIME:";
            // 
            // inputIme
            // 
            this.inputIme.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.inputIme.Location = new System.Drawing.Point(205, 74);
            this.inputIme.Name = "inputIme";
            this.inputIme.Size = new System.Drawing.Size(140, 20);
            this.inputIme.TabIndex = 20;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(71, 74);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 13);
            this.label1.TabIndex = 19;
            this.label1.Text = "IME:";
            // 
            // FormaRegistracija
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(399, 458);
            this.Controls.Add(this.btnRegistrirajSe);
            this.Controls.Add(this.btnIzlaz);
            this.Controls.Add(this.inputKontakt);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.inputAdresa);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.inputPotvrdaLozinke);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.inputLozinka);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.inputEmail);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.inputPrezime);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.inputIme);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Name = "FormaRegistracija";
            this.Text = "Registracija korisnika";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnRegistrirajSe;
        private System.Windows.Forms.Button btnIzlaz;
        private System.Windows.Forms.TextBox inputKontakt;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox inputAdresa;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox inputPotvrdaLozinke;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox inputLozinka;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox inputEmail;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox inputPrezime;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox inputIme;
        private System.Windows.Forms.Label label1;
    }
}